import os
import sys
import json
import google.generativeai as genai
import argparse

def generate_strategy(recon_data: str, api_key: str, knowledge_base_file: str) -> None:
    """Generate a scanning strategy using the Gemini API."""
    if not api_key:
        print("Error: Gemini API key not provided.")
        return

    try:
        with open(knowledge_base_file, 'r') as f:
            knowledge_base = json.load(f)
    except FileNotFoundError:
        knowledge_base = {}

    genai.configure(api_key=api_key)
    model = genai.GenerativeModel('gemini-pro')

    prompt = f"""Based on the following reconnaissance data and knowledge base, create a comprehensive scanning plan. The plan should be a JSON object containing a list of tasks. Each task should have a 'name', a 'command', and a list of 'dependencies'. The 'dependencies' list should contain the names of the tasks that must be completed before this task can start. The reconnaissance data is as follows:

{recon_data}

The knowledge base is as follows:

{json.dumps(knowledge_base, indent=2)}

Provide only the JSON object in your response.
"""

    try:
        response = model.generate_content(prompt)
        strategy = json.loads(response.text)
        print(json.dumps(strategy, indent=2))
    except Exception as e:
        print(f"Error generating strategy: {e}")

def main():
    parser = argparse.ArgumentParser(description='Strategy Generator')
    parser.add_argument('recon_data_file', help='Path to the reconnaissance data file')
    parser.add_argument('knowledge_base_file', help='Path to the knowledge base file')
    parser.add_argument('--api-key', help='Gemini API key')
    args = parser.parse_args()

    try:
        with open(args.recon_data_file, 'r') as f:
            recon_data = f.read()
        generate_strategy(recon_data, args.api_key, args.knowledge_base_file)
    except FileNotFoundError:
        print(f"Error: Reconnaissance data file not found at {args.recon_data_file}")

if __name__ == '__main__':
    main()
