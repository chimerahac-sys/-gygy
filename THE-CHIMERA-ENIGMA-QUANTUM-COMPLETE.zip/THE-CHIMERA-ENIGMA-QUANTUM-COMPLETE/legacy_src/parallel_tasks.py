#!/usr/bin/env python3
import os
import sys
import json
import argparse
import subprocess
import concurrent.futures


def run_cmd(cmd, cwd=None):
    result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return {"cmd": cmd, "returncode": result.returncode, "output": result.stdout}


def main():
    ap = argparse.ArgumentParser(description="Run external tools in parallel (fan-out)")
    ap.add_argument("--jobs", required=True, help="JSON file containing list of job specs")
    ap.add_argument("--out", required=True, help="Where to write combined results JSON")
    args = ap.parse_args()

    with open(args.jobs, "r", encoding="utf-8") as f:
        jobs = json.load(f)

    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(16, len(jobs) or 1)) as ex:
        futs = [ex.submit(run_cmd, j.get("cmd"), j.get("cwd")) for j in jobs]
        for fut in concurrent.futures.as_completed(futs):
            try:
                results.append(fut.result())
            except Exception as e:
                results.append({"cmd": [], "returncode": 1, "output": str(e)})

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"Executed {len(results)} jobs -> {args.out}")


if __name__ == "__main__":
    main()


