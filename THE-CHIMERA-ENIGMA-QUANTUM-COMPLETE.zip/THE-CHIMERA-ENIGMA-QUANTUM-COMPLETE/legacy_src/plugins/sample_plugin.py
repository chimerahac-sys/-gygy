from . import plugin


@plugin("sample_health_check")
def run(context):
    # context may include paths like workdir, outdir
    workdir = context.get('workdir', '')
    return {
        "workdir_exists": True if workdir else False,
        "notes": "Sample plugin executed"
    }


