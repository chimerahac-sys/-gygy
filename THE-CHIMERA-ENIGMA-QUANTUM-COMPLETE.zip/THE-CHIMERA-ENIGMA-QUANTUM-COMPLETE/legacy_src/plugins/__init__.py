# Simple plugin registry
REGISTRY = {}

def plugin(name):
    def _wrap(fn):
        REGISTRY[name] = fn
        return fn
    return _wrap

def run_all(context):
    results = {}
    for name, fn in REGISTRY.items():
        try:
            results[name] = fn(context)
        except Exception as e:
            results[name] = {"error": str(e)}
    return results


