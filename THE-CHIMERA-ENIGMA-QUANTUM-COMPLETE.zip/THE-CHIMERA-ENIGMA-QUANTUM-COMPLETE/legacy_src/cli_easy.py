#!/usr/bin/env python3
import os
import sys
import argparse
import subprocess
import shutil


def which_python():
    return sys.executable


def ensure_dirs(path: str):
    os.makedirs(path, exist_ok=True)


def run_orchestrator(workdir: str, output: str, html: bool = True) -> int:
    py = which_python()
    orchestrator = os.path.join(os.path.dirname(__file__), 'orchestrator.py')
    cmd = [py, orchestrator, workdir]
    if output:
        cmd += ['--output', output]
    if html:
        cmd.append('--html')
    return subprocess.call(cmd)


def main():
    parser = argparse.ArgumentParser(description='Easy Mode - One Command Bug Hunt AI')
    parser.add_argument('--targets', default='test_output', help='Folder berisi hasil scan/target input (default: test_output)')
    parser.add_argument('--output', default='reports', help='Folder output laporan (default: reports)')
    args = parser.parse_args()

    workdir = os.path.abspath(args.targets)
    outdir = os.path.abspath(args.output)
    ensure_dirs(workdir)
    ensure_dirs(outdir)

    # Jalankan orchestrator (otomatis)
    rc = run_orchestrator(workdir, outdir, html=True)
    if rc == 0:
        print('Selesai. Laporan ada di folder:', outdir)
        sys.exit(0)
    else:
        print('Terjadi kesalahan. Coba lagi atau cek log di folder output.')
        sys.exit(rc)


if __name__ == '__main__':
    main()


