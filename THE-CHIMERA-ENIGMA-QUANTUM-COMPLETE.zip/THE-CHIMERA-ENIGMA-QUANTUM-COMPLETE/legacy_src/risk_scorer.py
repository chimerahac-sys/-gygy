#!/usr/bin/env python3
import os
import sys
import json
import sqlite3
import argparse


def load_cve_scores(conn):
    scores = {}
    cur = conn.cursor()
    for (cve, cvss) in cur.execute("SELECT cve_id, cvss FROM cves"):
        scores[cve] = cvss or 0.0
    kev = set([row[0] for row in cur.execute("SELECT cve_id FROM kev")])
    return scores, kev


def score_finding(f, cve_scores, kev_set):
    base = 0.5
    sev = f.get('severity', 'info').lower()
    base += {'critical': 0.4, 'high': 0.3, 'medium': 0.2, 'low': 0.1, 'info': 0.0}.get(sev, 0.0)
    # If description contains a CVE, adjust
    desc = (f.get('description') or '') + ' ' + (f.get('evidence') or '')
    for token in desc.split():
        if token.startswith('CVE-') and token in cve_scores:
            base = max(base, min(1.0, 0.2 + (cve_scores[token] / 10.0)))
            if token in kev_set:
                base = min(1.0, base + 0.1)
    return round(base, 2)


def main():
    ap = argparse.ArgumentParser(description="Risk scorer using local threat intel DB")
    ap.add_argument("--db", required=True)
    ap.add_argument("--findings", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    conn = sqlite3.connect(args.db)
    cve_scores, kev_set = load_cve_scores(conn)
    conn.close()

    with open(args.findings, 'r', encoding='utf-8') as f:
        findings = json.load(f)

    for f in findings:
        f['risk_score_ti'] = score_finding(f, cve_scores, kev_set)

    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(findings, f, indent=2)

    print(f"Scored {len(findings)} findings -> {args.out}")


if __name__ == '__main__':
    main()


