#!/usr/bin/env python3
import os
import sys
import json
import argparse
from collections import defaultdict
from datetime import datetime


def load_json(path: str):
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def dedupe_findings(findings):
    if not findings:
        return []
    seen = set()
    result = []
    for f in findings:
        key = (f.get('type'), f.get('target'), f.get('description'))
        if key not in seen:
            seen.add(key)
            result.append(f)
    return result


def merge_findings(workdir: str):
    merged = []
    for name in ['findings.json', 'auth_findings.json', 'idor_findings.json', 'ssrf_findings.json', 'misconfig_findings.json', 'crypto_findings.json', 'logging_findings.json', 'design_findings.json', 'integrity_findings.json']:
        p = os.path.join(workdir, name)
        data = load_json(p)
        if isinstance(data, list):
            merged.extend(data)
    return merged


def export_markdown(findings, outdir: str):
    md = os.path.join(outdir, 'consolidated_report.md')
    with open(md, 'w', encoding='utf-8') as f:
        f.write("# Consolidated Vulnerability Report\n\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n\n")
        for i, v in enumerate(findings, 1):
            f.write(f"## {i}. {v.get('type','unknown').title()}\n\n")
            f.write(f"- Target: `{v.get('target','')}`\n")
            f.write(f"- Severity: {v.get('severity','info')}\n")
            f.write(f"- Confidence: {v.get('confidence',0)}\n")
            f.write(f"- Description: {v.get('description','')}\n")
            if v.get('poc'):
                f.write("\n```)\n")
                f.write(str(v['poc']))
                f.write("\n```\n\n")
            f.write("---\n\n")
    return md


def main():
    parser = argparse.ArgumentParser(description='Post-process findings: merge, dedupe, export')
    parser.add_argument('--workdir', required=True)
    parser.add_argument('--outdir', required=True)
    parser.add_argument('--html', action='store_true')
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    merged = merge_findings(args.workdir)
    merged = dedupe_findings(merged)
    merged_path = os.path.join(args.outdir, 'consolidated_findings.json')
    with open(merged_path, 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2)

    export_markdown(merged, args.outdir)

    print(f"Merged {len(merged)} findings → {merged_path}")


if __name__ == '__main__':
    main()


