#!/usr/bin/env python3
import os
import sys
import json
import argparse
import shutil


COMMON_TOOLS = [
    "nmap", "naabu", "masscan", "httpx", "subfinder", "amass", "assetfinder",
    "gau", "waybackurls", "katana", "gobuster", "ffuf", "nuclei", "dalfox",
    "wpscan", "nikto", "whatweb", "wafw00f", "sslyze", "aquatone", "subjack"
]


def which(tool: str):
    return shutil.which(tool)


def discover():
    found = {}
    for t in COMMON_TOOLS:
        p = which(t)
        if p:
            found[t] = p
    return found


def smart_defaults(tool: str, inputs: dict, workdir: str):
    # Minimal heuristics for sane defaults
    if tool == "nmap":
        target = inputs.get("target") or inputs.get("host") or "127.0.0.1"
        return ["nmap", "-sV", "-T4", "-oN", os.path.join(workdir, f"nmap-{target}.txt"), target]
    if tool == "httpx":
        infile = inputs.get("list") or inputs.get("file") or os.path.join(workdir, "all-subdomains.txt")
        return ["httpx", "-l", infile, "-silent", "-status-code", "-tech-detect", "-o", os.path.join(workdir, "httpx.txt")]
    if tool == "nuclei":
        infile = inputs.get("list") or os.path.join(workdir, "alive-subdomains.txt")
        return ["nuclei", "-l", infile, "-t", "cves,misconfiguration,exposures,technologies", "-o", os.path.join(workdir, "nuclei.txt")]
    return []


def main():
    ap = argparse.ArgumentParser(description="Discover Kali tools and propose/run smart defaults")
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--print", action="store_true")
    ap.add_argument("--run", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.workdir, exist_ok=True)
    found = discover()
    plan = []
    for t in found.keys():
        cmd = smart_defaults(t, {}, args.workdir)
        if cmd:
            plan.append({"tool": t, "cmd": cmd})

    out = {"found": found, "plan": plan}
    if args.print:
        print(json.dumps(out, indent=2))
        return

    if args.run and plan:
        import subprocess
        for job in plan:
            subprocess.run(job["cmd"])  # no strict fail, let orchestrator handle retries


if __name__ == "__main__":
    main()


