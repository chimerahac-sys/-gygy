#!/usr/bin/env python3
import os
import sys
import json
import time
import argparse
from urllib.parse import urlparse

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager


def make_driver(headless: bool = True):
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--window-size=1920,1080")
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=opts)
    return driver


def analyze_page(driver, url: str) -> dict:
    data = {"url": url, "issues": [], "meta": {}}
    t0 = time.time()
    driver.get(url)
    time.sleep(1.0)
    data["meta"]["title"] = driver.title
    data["meta"]["load_ms"] = int((time.time() - t0) * 1000)
    # Simple heuristics
    src = driver.page_source or ""
    lower = src.lower()
    if "x-frame-options" not in lower and "content-security-policy" not in lower:
        data["issues"].append({"type": "missing_security_headers", "severity": "low"})
    if "csrf" not in lower and "xsrf" not in lower:
        data["issues"].append({"type": "csrf_unknown", "severity": "info"})
    return data


def main():
    ap = argparse.ArgumentParser(description="Headless browser tester with simple AI heuristics")
    ap.add_argument("input", help="File containing URLs (one per line)")
    ap.add_argument("output", help="Output JSON file")
    ap.add_argument("--headed", action="store_true")
    args = ap.parse_args()

    urls = []
    with open(args.input, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            u = line.strip()
            if u:
                urls.append(u)

    driver = make_driver(headless=not args.headed)
    results = []
    try:
        for u in urls[:50]:
            try:
                results.append(analyze_page(driver, u))
            except Exception:
                continue
    finally:
        driver.quit()

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"Analyzed {len(results)} pages -> {args.output}")


if __name__ == "__main__":
    main()


