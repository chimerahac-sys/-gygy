import os
import sys
import json
import argparse

def update_knowledge_base(findings_file: str, knowledge_base_file: str) -> None:
    """Update the knowledge base with the results of a scan."""
    try:
        with open(findings_file, 'r') as f:
            findings = json.load(f)
    except FileNotFoundError:
        print(f"Error: Findings file not found at {findings_file}")
        return

    try:
        with open(knowledge_base_file, 'r') as f:
            knowledge_base = json.load(f)
    except FileNotFoundError:
        knowledge_base = {}

    for finding in findings:
        if finding.get('validated'):
            tool = finding.get('evidence', 'unknown').split(' ')[1]
            vuln_type = finding.get('type')
            target_tech = finding.get('target_tech')

            if target_tech not in knowledge_base:
                knowledge_base[target_tech] = {}
            if vuln_type not in knowledge_base[target_tech]:
                knowledge_base[target_tech][vuln_type] = {}
            if tool not in knowledge_base[target_tech][vuln_type]:
                knowledge_base[target_tech][vuln_type][tool] = {'success_rate': 0, 'count': 0}

            # Update success rate (simple weighted average)
            old_success_rate = knowledge_base[target_tech][vuln_type][tool]['success_rate']
            old_count = knowledge_base[target_tech][vuln_type][tool]['count']
            new_count = old_count + 1
            new_success_rate = (old_success_rate * old_count + 1) / new_count
            knowledge_base[target_tech][vuln_type][tool]['success_rate'] = new_success_rate
            knowledge_base[target_tech][vuln_type][tool]['count'] = new_count

    with open(knowledge_base_file, 'w') as f:
        json.dump(knowledge_base, f, indent=2)

def main():
    parser = argparse.ArgumentParser(description='Knowledge Base Updater')
    parser.add_argument('findings_file', help='Path to the findings.json file')
    parser.add_argument('knowledge_base_file', help='Path to the knowledge_base.json file')
    args = parser.parse_args()

    update_knowledge_base(args.findings_file, args.knowledge_base_file)

if __name__ == '__main__':
    main()
