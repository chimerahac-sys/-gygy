import os
import sys
import json
import logging
import argparse
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from collections import defaultdict, Counter
import re
import yaml
import hashlib
import pickle
import warnings

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential, Model
    from tensorflow.keras.layers import Dense, LSTM, Conv1D, Dropout, Input, Embedding
    from tensorflow.keras.optimizers import Adam
    from tensorflow.keras.callbacks import EarlyStopping
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    TF_AVAILABLE = True
except ImportError:
    print("TensorFlow not installed")
    TF_AVAILABLE = False
try:
    import gensim
    from gensim.models import Word2Vec, Doc2Vec
    from gensim.models.phrases import Phrases, Phraser
    import spacy
    NLP_AVAILABLE = True
except ImportError:
    print("Gensim not installed")
    NLP_AVAILABLE = False

import networkx as nx
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
from joblib import Parallel, delayed

warnings.filterwarnings('ignore')

class AdvancedAIStrategyPlanner:
    def __init__(self, workdir: str, output_file: str, config_file: str = None):
        self.workdir = workdir
        self.output_file = output_file
        self.strategy = {}
        self.target_data = {}
        self.models = {}
        self.scalers = {}

        # Load configuration
        self.config = self.load_config(config_file)
        
        # Setup advanced logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(workdir, 'ai_strategy_planner.log')),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Initialize AI models
        self.initialize_models()
    
def load_config(self, config_file: str = None) -> Dict[str, Any]:
    """Load configuration from file or use defaults"""
    default_config = {
        'scan_intensity': 'aggressive',
        'max_targets': 50,
        'time_limit': 14400,  # 4 hours
        'resource_allocation': {
            'recon': 0.3,
            'vulnerability_scanning': 0.4,
            'exploitation': 0.2,
            'reporting': 0.1
        },
        'risk_tolerance': 'medium',
        'focus_areas': ['web_applications', 'apis', 'infrastructure'],
        'exclusion_patterns': ['staging', 'test', 'dev'],
        'priority_technologies': ['wordpress', 'jenkins', 'jira', 'drupal'],
        'custom_payloads': True,
        'adaptive_learning': True,
        'max_parallel_processes': 8
    }
    
    if config_file and os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                user_config = yaml.safe_load(f)
            # Merge with default config
            default_config.update(user_config)
            self.logger.info(f"Loaded configuration from {config_file}")
        except Exception as e:
            self.logger.error(f"Error loading config file: {e}")
    
    return default_config

def initialize_models(self):
    """Initialize AI models for strategic planning"""
    self.models = {
        'target_priority': RandomForestClassifier(
            n_estimators=200,
            random_state=42,
            class_weight='balanced'
        ),
        'vulnerability_prediction': GradientBoostingClassifier(
            n_estimators=100,
            random_state=42
        ),
        'attack_path': MLPClassifier(
            hidden_layer_sizes=(100, 50),
            random_state=42,
            max_iter=1000
        ),
        'technology_clustering': KMeans(n_clusters=5, random_state=42),
        'threat_modeling': SVC(probability=True, random_state=42)
    }
    
    if TF_AVAILABLE:
        self.models['deep_target_analysis'] = self.build_deep_learning_model()
    
    self.logger.info("AI strategy models initialized successfully")

def build_deep_learning_model(self) -> tf.keras.Model:
    """Build deep learning model for target analysis"""
    model = Sequential([
        Dense(128, activation='relu', input_shape=(50,)),
        Dropout(0.3),
        Dense(64, activation='relu'),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dense(5, activation='softmax')  # 5 priority levels
    ])
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    return model

def load_target_data(self):
    """Load and process all available target data"""
    self.logger.info("Loading target data from work directory...")
    
    data_sources = {
        'subdomains': self.load_file('all-subdomains.txt'),
        'alive_subdomains': self.load_file('alive-subdomains.txt'),
        'urls': self.load_file('all-urls.txt'),
        'technology': self.load_technology_data(),
        'ports': self.load_port_data(),
        'vulnerabilities': self.load_vulnerability_data(),
        'content': self.load_content_data()
    }
    
    # Process each data source
    for name, data in data_sources.items():
        if data:
            self.target_data[name] = data
            self.logger.info(f"Loaded {len(data)} entries from {name}")
        else:
            self.logger.warning(f"No data found for {name}")
    
    # Create comprehensive target list
    self.targets = self.create_target_list()
    self.logger.info(f"Created target list with {len(self.targets)} entries")

def load_file(self, filename: str) -> List[str]:
    """Load data from file"""
    filepath = os.path.join(self.workdir, filename)
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                return [line.strip() for line in f if line.strip()]
        except Exception as e:
            self.logger.error(f"Error loading {filename}: {e}")
    return []

def load_technology_data(self) -> Dict[str, List[str]]:
    """Load technology detection data"""
    tech_data = {}
    tech_files = [f for f in os.listdir(self.workdir) if f.startswith('whatweb-')]
    
    for tech_file in tech_files:
        target = tech_file.replace('whatweb-', '').replace('.txt', '')
        filepath = os.path.join(self.workdir, tech_file)
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            tech_data[target] = self.parse_technology_info(content)
        except Exception as e:
            self.logger.error(f"Error parsing technology file {tech_file}: {e}")
    
    return tech_data

def parse_technology_info(self, content: str) -> List[str]:
    """Parse technology information from whatweb output"""
    technologies = []
    patterns = [
        r'WordPress\[[^\]]+\]',
        r'PHP\[[^\]]+\]',
        r'Apache\[[^\]]+\]',
        r'nginx\[[^\]]+\]',
        r'Joomla\[[^\]]+\]',
        r'Drupal\[[^\]]+\]',
        r'Jenkins\[[^\]]+\]',
        r'Jira\[[^\]]+\]'
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, content)
        technologies.extend(matches)
    
    return technologies

def load_port_data(self) -> Dict[str, List[int]]:
    """Load port scanning data"""
    port_data = {}
    port_files = [f for f in os.listdir(self.workdir) if f.startswith('nmap-') or f.startswith('naabu-')]
    
    for port_file in port_files:
        target = port_file.replace('nmap-', '').replace('naabu-', '').replace('.txt', '')
        filepath = os.path.join(self.workdir, port_file)
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            port_data[target] = self.parse_port_info(content)
        except Exception as e:
            self.logger.error(f"Error parsing port file {port_file}: {e}")
    
    return port_data

def parse_port_info(self, content: str) -> List[int]:
    """Parse port information from scan results"""
    ports = []
    # Match port numbers in various formats
    patterns = [
        r'(\d+)/tcp',
        r'PORT\s+STATE\s+SERVICE\n((?:\d+/tcp\s+open.+\n)+)',
        r'(\d+)\s+open'
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, content)
        for match in matches:
            if isinstance(match, tuple):
                match = match[0]
            if match.isdigit():
                ports.append(int(match))
    
    return list(set(ports))  # Remove duplicates

def load_vulnerability_data(self) -> Dict[str, List[Dict]]:
    """Load vulnerability scan data"""
    vuln_data = {}
    vuln_files = [f for f in os.listdir(self.workdir) if f.startswith('nuclei-') or f.startswith('nikto-')]
    
    for vuln_file in vuln_files:
        target = vuln_file.replace('nuclei-', '').replace('nikto-', '').replace('.txt', '')
        filepath = os.path.join(self.workdir, vuln_file)
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            vuln_data[target] = self.parse_vulnerability_info(content)
        except Exception as e:
            self.logger.error(f"Error parsing vulnerability file {vuln_file}: {e}")
    
    return vuln_data

def parse_vulnerability_info(self, content: str) -> List[Dict]:
    """Parse vulnerability information from scan results"""
    vulnerabilities = []
    lines = content.split('\n')
    
    for line in lines:
        if not line.strip():
            continue
            
        vuln = {
            'raw': line,
            'severity': 'unknown',
            'type': 'unknown',
            'confidence': 0.5
        }
        
        # Parse severity
        severity_patterns = [
            (r'\[critical\]', 'critical'),
            (r'\[high\]', 'high'),
            (r'\[medium\]', 'medium'),
            (r'\[low\]', 'low'),
            (r'\[info\]', 'info')
        ]
        
        for pattern, severity in severity_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                vuln['severity'] = severity
                break
        
        # Parse vulnerability type
        type_patterns = [
            (r'sql.*injection', 'sql_injection'),
            (r'xss', 'xss'),
            (r'cross.*site', 'xss'),
            (r'lfi', 'lfi'),
            (r'local.*file', 'lfi'),
            (r'rce', 'rce'),
            (r'remote.*code', 'rce'),
            (r'csrf', 'csrf'),
            (r'cross.*site.*request', 'csrf'),
            (r'ssrf', 'ssrf'),
            (r'server.*side.*request', 'ssrf'),
            (r'idor', 'idor'),
            (r'insecure.*direct.*object', 'idor')
        ]
        
        for pattern, vuln_type in type_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                vuln['type'] = vuln_type
                break
        
        vulnerabilities.append(vuln)
    
    return vulnerabilities

def load_content_data(self) -> Dict[str, Dict]:
    """Load content analysis data"""
    content_data = {}
    content_files = [f for f in os.listdir(self.workdir) if f.startswith('gobuster-') or f.startswith('ffuf-')]
    
    for content_file in content_files:
        target = content_file.split('-')[1].replace('.txt', '').replace('.json', '')
        filepath = os.path.join(self.workdir, content_file)
        
        try:
            if filepath.endswith('.json'):
                with open(filepath, 'r') as f:
                    content = json.load(f)
            else:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
            
            content_data[target] = self.parse_content_info(content, filepath)
        except Exception as e:
            self.logger.error(f"Error parsing content file {content_file}: {e}")
    
    return content_data

def parse_content_info(self, content: Any, filepath: str) -> Dict:
    """Parse content discovery information"""
    if filepath.endswith('.json'):
        # Parse FFUF JSON output
        if isinstance(content, dict) and 'results' in content:
            return {
                'type': 'ffuf_scan',
                'results': content['results'],
                'total': len(content['results'])
            }
    else:
        # Parse Gobuster text output
        lines = content.split('\n')
        directories = []
        for line in lines:
            if line.strip() and not line.startswith('#'):
                directories.append(line.strip())
        
        return {
            'type': 'gobuster_scan',
            'directories': directories,
            'total': len(directories)
        }
    
    return {'type': 'unknown', 'data': content}

def create_target_list(self) -> List[Dict[str, Any]]:
    """Create comprehensive target list with all available data"""
    targets = []
    
    # Use alive subdomains as base
    base_targets = self.target_data.get('alive_subdomains', [])
    if not base_targets:
        base_targets = self.target_data.get('subdomains', [])
    
    for target in base_targets:
        target_info = {
            'url': target,
            'domain': self.extract_domain(target),
            'technologies': self.target_data.get('technology', {}).get(target, []),
            'ports': self.target_data.get('ports', {}).get(target, []),
            'vulnerabilities': self.target_data.get('vulnerabilities', {}).get(target, []),
            'content': self.target_data.get('content', {}).get(target, {}),
            'priority_score': 0,
            'attack_vectors': [],
            'recommended_tools': [],
            'estimated_difficulty': 'medium'
        }
        
        # Calculate initial priority score
        target_info['priority_score'] = self.calculate_initial_priority(target_info)
        
        targets.append(target_info)
    
    return targets

def extract_domain(self, url: str) -> str:
    """Extract domain from URL"""
    try:
        # Remove protocol and path
        domain = url.split('//')[-1].split('/')[0]
        # Remove port if present
        domain = domain.split(':')[0]
        return domain
    except:
        return url

def calculate_initial_priority(self, target: Dict[str, Any]) -> float:
    """Calculate initial priority score for target"""
    score = 0.0
    
    # Base score for being alive
    score += 10.0
    
    # Technology-based scoring
    tech_priority = {
        'wordpress': 15.0,
        'jenkins': 20.0,
        'jira': 18.0,
        'drupal': 12.0,
        'php': 8.0,
        'apache': 5.0,
        'nginx': 5.0
    }
    
    for tech in target['technologies']:
        tech_lower = tech.lower()
        for tech_key, tech_score in tech_priority.items():
            if tech_key in tech_lower:
                score += tech_score
    
    # Port-based scoring
    sensitive_ports = {
        22: 10.0,    # SSH
        21: 8.0,     # FTP
        23: 5.0,     # Telnet
        25: 7.0,     # SMTP
        53: 6.0,     # DNS
        80: 3.0,     # HTTP
        443: 3.0,    # HTTPS
        8080: 8.0,   # HTTP Alt
        8443: 8.0,   # HTTPS Alt
        3389: 15.0,  # RDP
        5900: 12.0,  # VNC
        27017: 10.0  # MongoDB
    }
    
    for port in target['ports']:
        if port in sensitive_ports:
            score += sensitive_ports[port]
    
    # Vulnerability-based scoring
    severity_scores = {
        'critical': 25.0,
        'high': 15.0,
        'medium': 8.0,
        'low': 3.0,
        'info': 1.0,
        'unknown': 5.0
    }
    
    for vuln in target['vulnerabilities']:
        score += severity_scores.get(vuln.get('severity', 'unknown'), 5.0)
    
    # Content-based scoring
    if target.get('content'):
        content = target['content']
        if content.get('total', 0) > 10:
            score += content['total'] * 0.5
    
    return score

def analyze_targets(self):
    """Perform deep AI analysis on all targets"""
    self.logger.info("Performing AI-powered target analysis...")
    
    # Extract features for machine learning
    features = self.extract_features()
    
    # Train models if we have enough data
    if len(self.targets) > 10:
        self.train_models(features)
    
    # Predict priorities and attack vectors
    self.predict_strategies(features)
    
    # Generate overall strategy
    self.generate_overall_strategy()

def extract_features(self) -> np.ndarray:
    """Extract features for machine learning"""
    self.logger.info("Extracting features for AI analysis...")
    
    feature_arrays = []
    
    for target in self.targets:
        features = []
        
        # URL-based features
        url = target['url']
        features.append(len(url))
        features.append(url.count('.'))
        features.append(url.count('-'))
        features.append(1 if 'https' in url else 0)
        
        # Technology features
        tech_features = [0] * len(self.config['priority_technologies'])
        for i, tech in enumerate(self.config['priority_technologies']):
            for target_tech in target['technologies']:
                if tech in target_tech.lower():
                    tech_features[i] = 1
                    break
        features.extend(tech_features)
        
        # Port features
        port_features = [0] * 10  # Top 10 sensitive ports
        sensitive_ports = [22, 21, 23, 25, 53, 80, 443, 8080, 8443, 3389]
        for i, port in enumerate(sensitive_ports):
            if port in target['ports']:
                port_features[i] = 1
        features.extend(port_features)
        
        # Vulnerability features
        vuln_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for vuln in target['vulnerabilities']:
            severity = vuln.get('severity', 'unknown')
            if severity in vuln_counts:
                vuln_counts[severity] += 1
        features.extend(vuln_counts.values())
        
        feature_arrays.append(features)
    
    return np.array(feature_arrays)

def train_models(self, features: np.ndarray):
    """Train AI models on target features"""
    self.logger.info("Training AI models...")
    
    # Create labels based on priority scores
    labels = np.array([target['priority_score'] for target in self.targets])
    
    # Convert to classification problem (high, medium, low)
    label_bins = np.percentile(labels, [33, 66])
    classified_labels = np.digitize(labels, label_bins)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        features, classified_labels, test_size=0.2, random_state=42
    )
    
    # Scale features
    self.scalers['standard'] = StandardScaler()
    X_train_scaled = self.scalers['standard'].fit_transform(X_train)
    X_test_scaled = self.scalers['standard'].transform(X_test)
    
    # Train priority model
    self.models['target_priority'].fit(X_train_scaled, y_train)
    
    # Train other models
    self.models['vulnerability_prediction'].fit(X_train_scaled, y_train)
    self.models['attack_path'].fit(X_train_scaled, y_train)
    
    # Evaluate models
    train_score = self.models['target_priority'].score(X_train_scaled, y_train)
    test_score = self.models['target_priority'].score(X_test_scaled, y_test)
    
    self.logger.info(f"Model training completed. Train score: {train_score:.3f}, Test score: {test_score:.3f}")

def predict_strategies(self, features: np.ndarray):
    """Predict strategies for all targets"""
    self.logger.info("Predicting attack strategies...")
    
    if features.shape[0] == 0:
        self.logger.warning("No features available for prediction")
        return
    
    # Scale features
    if self.scalers.get('standard'):
        features_scaled = self.scalers['standard'].transform(features)
    else:
        features_scaled = features
    
    # Predict priorities
    if hasattr(self.models['target_priority'], 'predict'):
        priorities = self.models['target_priority'].predict(features_scaled)
    else:
        # Fallback to manual scoring
        priorities = [self.calculate_manual_priority(target) for target in self.targets]
    
    # Update targets with predictions
    for i, target in enumerate(self.targets):
        target['ai_priority'] = priorities[i] if i < len(priorities) else target['priority_score']
        target['attack_vectors'] = self.predict_attack_vectors(target)
        target['recommended_tools'] = self.recommend_tools(target)
        target['estimated_difficulty'] = self.estimate_difficulty(target)
        target['time_estimate'] = self.estimate_time(target)

def calculate_manual_priority(self, target: Dict[str, Any]) -> float:
    """Manual priority calculation fallback"""
    score = target['priority_score']
    
    # Adjust based on additional factors
    if any('wordpress' in tech.lower() for tech in target['technologies']):
        score *= 1.3
    
    if any('jenkins' in tech.lower() for tech in target['technologies']):
        score *= 1.5
    
    if any(vuln.get('severity') == 'critical' for vuln in target['vulnerabilities']):
        score *= 1.4
    
    return score

def predict_attack_vectors(self, target: Dict[str, Any]) -> List[str]:
    """Predict potential attack vectors for target"""
    attack_vectors = []
    
    # Technology-based vectors
    tech_vectors = {
        'wordpress': ['wp-admin brute force', 'plugin vulnerabilities', 'theme vulnerabilities', 'xmlrpc attacks'],
        'jenkins': ['jenkins script console', 'groovy script execution', 'jenkins CLI', 'authentication bypass'],
        'jira': ['jira injection attacks', 'template injection', 'authentication issues', 'information disclosure'],
        'drupal': ['drupalgeddon', 'module vulnerabilities', 'form API attacks', 'database injection'],
        'php': ['php injection', 'file inclusion', 'deserialization attacks', 'type juggling']
    }
    
    for tech in target['technologies']:
        tech_lower = tech.lower()
        for tech_key, vectors in tech_vectors.items():
            if tech_key in tech_lower:
                attack_vectors.extend(vectors)
    
    # Port-based vectors
    port_vectors = {
        22: ['SSH brute force', 'SSH key attacks', 'SSH configuration vulnerabilities'],
        21: ['FTP anonymous access', 'FTP brute force', 'FTP bounce attacks'],
        23: ['Telnet brute force', 'Telnet protocol attacks'],
        25: ['SMTP enumeration', 'SMTP injection', 'open relay attacks'],
        53: ['DNS zone transfer', 'DNS cache poisoning', 'DNS tunneling'],
        80: ['HTTP attacks', 'web application vulnerabilities'],
        443: ['HTTPS attacks', 'web application vulnerabilities', 'SSL/TLS vulnerabilities'],
        8080: ['HTTP proxy attacks', 'web application vulnerabilities'],
        8443: ['HTTPS alternative attacks', 'web application vulnerabilities'],
        3389: ['RDP brute force', 'RDP vulnerabilities', 'bluekeep attacks'],
        5900: ['VNC brute force', 'VNC authentication bypass'],
        27017: ['MongoDB unauthorized access', 'MongoDB injection']
    }
    
    for port in target['ports']:
        if port in port_vectors:
            attack_vectors.extend(port_vectors[port])
    
    # Vulnerability-based vectors
    for vuln in target['vulnerabilities']:
        vuln_type = vuln.get('type', '')
        if vuln_type == 'sql_injection':
            attack_vectors.append('SQL injection exploitation')
        elif vuln_type == 'xss':
            attack_vectors.append('XSS payload delivery')
        elif vuln_type == 'lfi':
            attack_vectors.append('Local file inclusion exploitation')
        elif vuln_type == 'rce':
            attack_vectors.append('Remote code execution')
    
    return list(set(attack_vectors))  # Remove duplicates

def recommend_tools(self, target: Dict[str, Any]) -> List[str]:
    """Recommend tools for attacking target"""
    tools = []
    
    # General recon tools
    tools.extend(['nmap', 'masscan', 'subfinder', 'amass', 'httpx'])
    
    # Technology-specific tools
    if any('wordpress' in tech.lower() for tech in target['technologies']):
        tools.extend(['wpscan', 'wpseku', 'jesus'])
    
    if any('jenkins' in tech.lower() for tech in target['technologies']):
        tools.extend(['jenkins-cli', 'jenkins-exploit'])
    
    # Vulnerability-specific tools
    if any(vuln.get('type') == 'sql_injection' for vuln in target['vulnerabilities']):
        tools.extend(['sqlmap', 'nosqlmap'])
    
    if any(vuln.get('type') == 'xss' for vuln in target['vulnerabilities']):
        tools.extend(['xsser', 'xss hunter', 'beef'])
    
    # Port-specific tools
    if 22 in target['ports']:
        tools.extend(['hydra', 'medusa', 'patator'])
    
    if 3389 in target['ports']:
        tools.extend(['rdp-sec-check', 'crowbar'])
    
    return list(set(tools))

def estimate_difficulty(self, target: Dict[str, Any]) -> str:
    """Estimate attack difficulty"""
    score = 0
    
    # Technology factors
    tech_difficulty = {
        'wordpress': 2,
        'jenkins': 3,
        'jira': 3,
        'drupal': 2,
        'php': 1
    }
    
    for tech in target['technologies']:
        tech_lower = tech.lower()
        for tech_key, diff_score in tech_difficulty.items():
            if tech_key in tech_lower:
                score += diff_score
    
    # Vulnerability factors
    for vuln in target['vulnerabilities']:
        severity = vuln.get('severity', '')
        if severity == 'critical':
            score -= 3  # Easier to exploit
        elif severity == 'high':
            score -= 2
        elif severity == 'medium':
            score -= 1
    
    # Determine difficulty level
    if score >= 5:
        return 'hard'
    elif score >= 2:
        return 'medium'
    else:
        return 'easy'

def estimate_time(self, target: Dict[str, Any]) -> int:
    """Estimate time required for target (in minutes)"""
    base_time = 30  # Base 30 minutes per target
    
    # Adjust based on factors
    time_factors = {
        'technologies': len(target['technologies']) * 5,
        'ports': len(target['ports']) * 2,
        'vulnerabilities': len(target['vulnerabilities']) * 10,
        'difficulty': {
            'easy': -10,
            'medium': 0,
            'hard': 20
        }[target['estimated_difficulty']]
    }
    
    total_time = base_time + sum(time_factors.values())
    return max(15, total_time)  # Minimum 15 minutes

def generate_overall_strategy(self):
    """Generate overall attack strategy"""
    self.logger.info("Generating overall attack strategy...")
    
    # Sort targets by priority
    sorted_targets = sorted(self.targets, key=lambda x: x.get('ai_priority', 0), reverse=True)
    
    # Apply target limit
    max_targets = self.config['max_targets']
    if len(sorted_targets) > max_targets:
        sorted_targets = sorted_targets[:max_targets]
    
    # Calculate time allocation
    total_time = self.config['time_limit']
    resource_allocation = self.config['resource_allocation']
    
    strategy = {
        'metadata': {
            'generated_at': datetime.now().isoformat(),
            'total_targets': len(sorted_targets),
            'time_limit_seconds': total_time,
            'scan_intensity': self.config['scan_intensity'],
            'risk_tolerance': self.config['risk_tolerance']
        },
        'resource_allocation': resource_allocation,
        'targets': sorted_targets,
        'phases': self.generate_attack_phases(sorted_targets, total_time, resource_allocation),
        'recommendations': self.generate_overall_recommendations()
    }
    
    self.strategy = strategy

def generate_attack_phases(self, targets: List[Dict], total_time: int, 
                          resource_allocation: Dict[str, float]) -> List[Dict]:
    """Generate detailed attack phases"""
    phases = []
    
    # Phase 1: Reconnaissance
    recon_time = total_time * resource_allocation['recon']
    phases.append({
        'name': 'Comprehensive Reconnaissance',
        'time_allocation': recon_time,
        'targets': [t['url'] for t in targets],
        'objectives': [
            'Deep subdomain enumeration',
            'Technology fingerprinting',
            'Content discovery',
            'API endpoint discovery',
            'JavaScript file analysis'
        ],
        'tools': ['subfinder', 'amass', 'httpx', 'gobuster', 'waybackurls', 'gau', 'katana'],
        'deliverables': ['Complete target map', 'Technology inventory', 'Content inventory']
    })
    
    # Phase 2: Vulnerability Assessment
    vuln_time = total_time * resource_allocation['vulnerability_scanning']
    phases.append({
        'name': 'Vulnerability Assessment',
        'time_allocation': vuln_time,
        'targets': [t['url'] for t in targets if t['ai_priority'] > 20],
        'objectives': [
            'Automated vulnerability scanning',
            'Manual vulnerability assessment',
            'Configuration review',
            'Authentication testing'
        ],
        'tools': ['nuclei', 'nikto', 'sqlmap', 'wpscan', 'testssl'],
        'deliverables': ['Vulnerability report', 'Risk assessment', 'Proof-of-concept concepts']
    })
    
    # Phase 3: Exploitation
    exploit_time = total_time * resource_allocation['exploitation']
    phases.append({
        'name': 'Focused Exploitation',
        'time_allocation': exploit_time,
        'targets': [t['url'] for t in targets if t['ai_priority'] > 30],
        'objectives': [
            'Vulnerability exploitation',
            'Privilege escalation',
            'Lateral movement',
            'Persistence establishment'
        ],
        'tools': ['metasploit', 'burpsuite', 'custom scripts', 'exploit-db'],
        'deliverables': ['Compromised systems', 'Access credentials', 'Exfiltrated data']
    })
    
    # Phase 4: Reporting
    report_time = total_time * resource_allocation['reporting']
    phases.append({
        'name': 'Reporting & Documentation',
        'time_allocation': report_time,
        'objectives': [
            'Vulnerability documentation',
            'Proof-of-concept creation',
            'Risk assessment',
            'Remediation recommendations'
        ],
        'tools': ['microsoft word', 'latex', 'screenshots', 'video recording'],
        'deliverables': ['Comprehensive report', 'Executive summary', 'Technical details']
    })
    
    return phases

def generate_overall_recommendations(self) -> Dict[str, Any]:
    """Generate overall recommendations"""
    # Analyze common vulnerabilities
    vuln_types = []
    for target in self.targets:
        for vuln in target['vulnerabilities']:
            vuln_types.append(vuln.get('type', 'unknown'))
    
    vuln_counter = Counter(vuln_types)
    
    # Generate recommendations based on findings
    recommendations = {
        'immediate_actions': [],
        'high_priority': [],
        'medium_priority': [],
        'low_priority': []
    }
    
    # Immediate actions for critical vulnerabilities
    if any(vuln.get('severity') == 'critical' for target in self.targets for vuln in target['vulnerabilities']):
        recommendations['immediate_actions'].append(
            "Address critical vulnerabilities immediately to prevent system compromise"
        )
    
    # Technology-specific recommendations
    all_tech = []
    for target in self.targets:
        all_tech.extend(target['technologies'])
    
    tech_counter = Counter(all_tech)
    for tech, count in tech_counter.most_common(5):
        recommendations['high_priority'].append(
            f"Review {tech} configuration and apply security patches ({count} instances)"
        )
    
    # Vulnerability-type recommendations
    for vuln_type, count in vuln_counter.most_common(3):
        recommendations['medium_priority'].append(
            f"Implement defenses against {vuln_type} attacks ({count} instances)"
        )
    
    return recommendations

def save_strategy(self):
    """Save strategy to output file"""
    self.logger.info(f"Saving strategy to {self.output_file}")
    
    # Create comprehensive output
    output = {
        'strategy': self.strategy,
        'target_details': self.targets,
        'configuration': self.config,
        'statistics': self.generate_strategy_statistics()
    }
    
    # Save as JSON
    with open(self.output_file, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    # Save human-readable version
    text_output = self.output_file.replace('.json', '_readable.txt')
    with open(text_output, 'w', encoding='utf-8') as f:
        f.write(self.generate_text_report())
    
    self.logger.info(f"Strategy saved to {self.output_file} and {text_output}")

def generate_strategy_statistics(self) -> Dict[str, Any]:
    """Generate statistics about the strategy"""
    stats = {
        'total_targets': len(self.targets),
        'high_priority_targets': len([t for t in self.targets if t.get('ai_priority', 0) > 50]),
        'medium_priority_targets': len([t for t in self.targets if 25 <= t.get('ai_priority', 0) <= 50]),
        'low_priority_targets': len([t for t in self.targets if t.get('ai_priority', 0) < 25]),
        'total_vulnerabilities': sum(len(t['vulnerabilities']) for t in self.targets),
        'critical_vulnerabilities': sum(1 for t in self.targets for v in t['vulnerabilities'] if v.get('severity') == 'critical'),
        'technology_distribution': Counter([tech for t in self.targets for tech in t['technologies']]),
        'estimated_total_time': sum(t.get('time_estimate', 0) for t in self.targets)
    }
    
    return stats

def generate_text_report(self) -> str:
    """Generate human-readable text report"""
    lines = [
        "=" * 80,
        "AI-POWERED BUG BOUNTY STRATEGY REPORT",
        "=" * 80,
        f"Generated: {self.strategy['metadata']['generated_at']}",
        f"Scan Intensity: {self.strategy['metadata']['scan_intensity']}",
        f"Risk Tolerance: {self.strategy['metadata']['risk_tolerance']}",
        f"Total Targets: {self.strategy['metadata']['total_targets']}",
        f"Time Limit: {self.strategy['metadata']['time_limit_seconds']} seconds",
        "",
        "RESOURCE ALLOCATION:",
        "-" * 40
    ]
    
    for phase, allocation in self.strategy['resource_allocation'].items():
        lines.append(f"{phase.replace('_', ' ').title()}: {allocation * 100:.1f}%")
    
    lines.extend(["", "ATTACK PHASES:", "-" * 40])
    
    for i, phase in enumerate(self.strategy['phases'], 1):
        lines.extend([
            f"{i}. {phase['name']}",
            f"   Time: {phase['time_allocation'] / 60:.1f} minutes",
            f"   Targets: {len(phase.get('targets', []))}",
            f"   Objectives: {', '.join(phase['objectives'][:3])}...",
            ""
        ])
    
    lines.extend(["TARGET PRIORITIZATION:", "-" * 40])
    
    for i, target in enumerate(self.strategy['targets'][:10], 1):  # Top 10 targets
        lines.extend([
            f"{i}. {target['url']}",
            f"   Priority: {target.get('ai_priority', 0):.1f}",
            f"   Difficulty: {target.get('estimated_difficulty', 'unknown')}",
            f"   Time Estimate: {target.get('time_estimate', 0)} minutes",
            f"   Attack Vectors: {', '.join(target.get('attack_vectors', [])[:3])}...",
            ""
        ])
    
    lines.extend(["RECOMMENDATIONS:", "-" * 40])
    
    for priority, recs in self.strategy['recommendations'].items():
        if recs:
            lines.append(f"{priority.replace('_', ' ').title()}:")
            for rec in recs:
                lines.append(f"  • {rec}")
            lines.append("")
    
    return "\n".join(lines)

def run(self):
    """Main execution method"""
    try:
        # Load target data
        self.load_target_data()
        
        if not self.targets:
            self.logger.error("No target data available for strategy planning")
            return
        
        # Analyze targets
        self.analyze_targets()
        
        # Save strategy
        self.save_strategy()
        
        self.logger.info("AI strategy planning completed successfully")
        
    except Exception as e:
        self.logger.error(f"Error in strategy planning: {e}")
        raise
def main():
    parser = argparse.ArgumentParser(description='Advanced AI-Powered Bug Bounty Strategy Planner')
    parser.add_argument('workdir', help='Working directory with scan results')
    parser.add_argument('output_file', help='Output file for strategy (JSON format)')
    parser.add_argument('--config', '-c', help='Configuration file (YAML format)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')

    args = parser.parse_args()

    # Set logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Run strategy planning
    planner = AdvancedAIStrategyPlanner(args.workdir, args.output_file, args.config)
    planner.run()


if __name__ == "__main__":
    main()

