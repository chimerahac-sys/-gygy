import requests
from bs4 import BeautifulSoup
import spacy
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class ThreatIntelligenceFeeder:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.gan = ThreatGAN(input_dim=100, hidden_dim=256).to(self.device)
        self.gan_optimizer_g = optim.Adam(self.gan.generator.parameters(), lr=0.0002)
        self.gan_optimizer_d = optim.Adam(self.gan.discriminator.parameters(), lr=0.0002)

    def collect_threat_data(self, sources):
        threat_data = []
        for source in sources:
            try:
                if "http" in source:
                    response = requests.get(source)
                    response.raise_for_status()
                    soup = BeautifulSoup(response.content, "html.parser")
                    text_data = soup.get_text()
                else:
                    with open(source, "r") as f:
                        text_data = f.read()

                threat_data.append(text_data)
            except Exception as e:
                print(f"Error collecting data from {source}: {e}")
        return threat_data

    def analyze_threat_data(self, threat_data):
        threat_indicators = []
        for data in threat_data:
            doc = self.nlp(data)
            for entity in doc.ents:
                threat_indicators.append({"text": entity.text, "label": entity.label_})
        return threat_indicators

    def generate_adversarial_samples(self, num_samples=10):
        self.gan.train()
        generated_samples = []
        for _ in range(num_samples):
            noise = torch.randn(1, 100).to(self.device)
            generated_sample = self.gan.generator(noise)
            generated_samples.append(generated_sample.detach().cpu().numpy())
        return generated_samples

    def train_gan(self, real_samples, epochs=10):
        self.gan.train()
        criterion = nn.BCELoss()

        for epoch in range(epochs):
            # Train Discriminator
            self.gan_optimizer_d.zero_grad()
            real_data = torch.tensor(real_samples).float().to(self.device)
            batch_size = real_data.size(0)
            real_labels = torch.ones(batch_size, 1).to(self.device)
            output_real = self.gan.discriminator(real_data)
            loss_real = criterion(output_real, real_labels)
            loss_real.backward()

            noise = torch.randn(batch_size, 100).to(self.device)
            fake_data = self.gan.generator(noise)
            fake_labels = torch.zeros(batch_size, 1).to(self.device)
            output_fake = self.gan.discriminator(fake_data.detach())
            loss_fake = criterion(output_fake, fake_labels)
            loss_fake.backward()

            self.gan_optimizer_d.step()

            # Train Generator
            self.gan_optimizer_g.zero_grad()
            noise = torch.randn(batch_size, 100).to(self.device)
            fake_data = self.gan.generator(noise)
            output_fake = self.gan.discriminator(fake_data)
            loss_generator = criterion(output_fake, real_labels)
            loss_generator.backward()
            self.gan_optimizer_g.step()

            print(f"Epoch [{epoch+1}/{epochs}], Loss D: {loss_real.item() + loss_fake.item():.4f}, Loss G: {loss_generator.item():.4f}")

    def process_threats(self, sources, epochs=10, num_adversarial_samples=10):
        threat_data = self.collect_threat_data(sources)
        threat_indicators = self.analyze_threat_data(threat_data)

        # Convert threat indicators to numerical data for GAN training
        real_samples = np.array([self._convert_indicator_to_vector(indicator) for indicator in threat_indicators])

        # Train the GAN
        self.train_gan(real_samples, epochs)

        # Generate adversarial samples
        adversarial_samples = self.generate_adversarial_samples(num_adversarial_samples)

        return threat_indicators, adversarial_samples

    def _convert_indicator_to_vector(self, indicator):
        # Simple conversion for demonstration purposes
        text_embedding = self.nlp(indicator["text"]).vector
        label_embedding = np.zeros(5)  # Assuming 5 possible labels
        try:
            label_index = {"ORG": 0, "PERSON": 1, "GPE": 2, "LOC": 3, "MISC": 4}[indicator["label"]]
            label_embedding[label_index] = 1
        except KeyError:
            pass
        return np.concatenate([text_embedding, label_embedding])

class ThreatGAN(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(ThreatGAN, self).__init__()
        self.generator = Generator(input_dim, hidden_dim)
        self.discriminator = Discriminator(input_dim + 768 + 5, hidden_dim) # Adjusted input dimension

class Generator(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 768 + 5),
            nn.Tanh()
        )

    def forward(self, x):
        return self.model(x)

class Discriminator(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)

if __name__ == "__main__":
    feeder = ThreatIntelligenceFeeder()
    threat_sources = [
        "https://www.threatminer.org/latest.php",
        "https://www.us-cert.gov/ncas/current-activity"
    ]

    threat_indicators, adversarial_samples = feeder.process_threats(threat_sources, epochs=2)

    print("\nThreat Indicators:")
    for indicator in threat_indicators:
        print(indicator)

    print("\nGenerated Adversarial Samples:")
    for sample in adversarial_samples:
        print(sample.shape)
