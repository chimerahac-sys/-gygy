
import argparse
import sys
import json
import os

try:
    import google.generativeai as genai
except ImportError:
    print("Error: google-generativeai library not found. Please run 'pip install -r requirements.txt'")
    sys.exit(1)

# --- Configuration ---
# It's better to use environment variables for API keys
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    # As a fallback, try to read from the main config file if it exists
    try:
        import yaml
        with open('configs/main_config.yml', 'r') as f:
            config = yaml.safe_load(f)
            API_KEY = config.get('api_keys', {}).get('gemini')
    except (FileNotFoundError, ImportError, AttributeError):
        print("Error: GEMINI_API_KEY not found in environment variables or configs/main_config.yml")
        sys.exit(1)

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel('gemini-pro')

# --- AI Analysis Functions ---

def prioritize_subdomains(input_file: str):
    """Reads a list of subdomains and uses AI to prioritize them."""
    try:
        with open(input_file, 'r') as f:
            subdomains = [line.strip() for line in f.readlines() if line.strip()]
    except FileNotFoundError:
        print(f"Error: Input file not found at {input_file}")
        return

    if not subdomains:
        print("Input file is empty. No subdomains to prioritize.")
        return

    prompt = f"""
    You are a master penetration tester. Given the following list of subdomains, identify the top 5 most interesting targets for a security assessment. 
    Interesting targets might include those with keywords like 'admin', 'dev', 'api', 'vpn', 'remote', 'test', 'staging', or other non-standard names.

    Subdomain List:
    {json.dumps(subdomains[:200])} # Limit to avoid excessive prompt length

    Respond with ONLY a JSON object containing a single key "prioritized_subdomains", which is a list of the top 5 most promising subdomain strings.
    Example: {{"prioritized_subdomains": ["admin.example.com", "api.dev.example.com"]}}
    """

    try:
        response = model.generate_content(prompt)
        result = json.loads(response.text)
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Error during AI analysis: {e}")

def validate_vulnerability(vuln_json: str):
    """Receives a JSON string of a vulnerability and uses AI to validate it."""
    try:
        vuln_data = json.loads(vuln_json)
    except json.JSONDecodeError:
        print("Error: Invalid JSON string provided for vulnerability.")
        return

    prompt = f"""
    You are a senior security analyst. A scanner reported the following vulnerability. Your task is to determine if it is likely a true positive.

    Vulnerability Details:
    {json.dumps(vuln_data, indent=2)}

    Analyze the details. Based on the template-id, matched-at, and name, assess the likelihood of this being a true positive.

    Respond with ONLY a JSON object with two keys:
    1. "is_true_positive": boolean (true if you believe it is a real vulnerability, false otherwise)
    2. "justification": string (a brief, technical reason for your assessment)
    """

    try:
        response = model.generate_content(prompt)
        result = json.loads(response.text)
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Error during AI analysis: {e}")

# --- Main Execution ---

def main():
    parser = argparse.ArgumentParser(description="The Chimera Enigma - AI Analyzer Tool")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    # Sub-parser for prioritizing subdomains
    parser_prio = subparsers.add_parser("prioritize-subdomains", help="Prioritize a list of subdomains.")
    parser_prio.add_argument("input_file", help="Path to a text file containing a list of subdomains.")

    # Sub-parser for validating a vulnerability
    parser_val = subparsers.add_parser("validate-vulnerability", help="Validate a single vulnerability finding.")
    parser_val.add_argument("vulnerability_json", help="A JSON string representing the vulnerability to validate.")

    args = parser.parse_args()

    if args.mode == "prioritize-subdomains":
        prioritize_subdomains(args.input_file)
    elif args.mode == "validate-vulnerability":
        validate_vulnerability(args.vulnerability_json)

if __name__ == "__main__":
    main()
