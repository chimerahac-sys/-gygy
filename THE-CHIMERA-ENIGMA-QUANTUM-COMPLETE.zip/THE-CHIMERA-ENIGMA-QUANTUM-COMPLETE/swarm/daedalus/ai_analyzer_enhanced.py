#!/usr/bin/env python3
"""
Enhanced AI-Powered Vulnerability Analyzer
Ultimate AI-driven security assessment with advanced machine learning
Author: Azkiah Darojah (Vectal 2025)
"""

import os
import sys
import json
import logging
import argparse
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from collections import defaultdict, Counter
import re
import yaml
import hashlib
import pickle
import warnings
import concurrent.futures
import threading
import queue
import time
import requests
from urllib.parse import urlparse, urljoin, quote, unquote
from bs4 import BeautifulSoup
import base64
import hashlib
import sqlite3
import xml.etree.ElementTree as ET

# Advanced ML Libraries
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.preprocessing import StandardScaler, LabelEncoder, RobustScaler
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.svm import SVC, OneClassSVM
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, silhouette_score
from sklearn.linear_model import LogisticRegression, Ridge, Lasso
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import MultinomialNB, GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis

# Deep Learning
try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential, Model
    from tensorflow.keras.layers import Dense, LSTM, Conv1D, Dropout, Input, Embedding, Bidirectional, Attention
    from tensorflow.keras.optimizers import Adam, RMSprop, SGD
    from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    from tensorflow.keras.utils import to_categorical
    TF_AVAILABLE = True
except ImportError:
    print("TensorFlow not available - some features will be limited")
    TF_AVAILABLE = False

# NLP Libraries
try:
    import gensim
    from gensim.models import Word2Vec, Doc2Vec, FastText
    from gensim.models.phrases import Phrases, Phraser
    import spacy
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
    import torch
    NLP_AVAILABLE = True
except ImportError:
    print("Advanced NLP libraries not available")
    NLP_AVAILABLE = False

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import networkx as nx
from scipy import stats
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import pdist, squareform

# Parallel Processing
from joblib import Parallel, delayed
import multiprocessing as mp

# API Integration
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

warnings.filterwarnings('ignore')

class AdvancedAIVulnerabilityAnalyzer:
    """
    Ultimate AI-powered vulnerability analyzer with advanced machine learning capabilities
    """
    
    def __init__(self, workdir: str, output_dir: str, config_file: str = None):
        self.workdir = workdir
        self.output_dir = output_dir
        self.config = self.load_config(config_file)
        
        # Initialize AI models
        self.models = {}
        self.scalers = {}
        self.vectorizers = {}
        self.encoders = {}
        
        # Data storage
        self.target_data = {}
        self.vulnerability_data = {}
        self.analysis_results = {}
        
        # Threading
        self.task_queue = queue.Queue()
        self.results_queue = queue.Queue()
        self.threads = []
        
        # Setup logging
        self.setup_logging()
        
        # Initialize AI components
        self.initialize_ai_models()
        
        self.logger.info("Advanced AI Vulnerability Analyzer initialized successfully")
    
    def load_config(self, config_file: str = None) -> Dict[str, Any]:
        """Load configuration with advanced settings"""
        default_config = {
            'ai_models': {
                'vulnerability_classifier': {
                    'type': 'ensemble',
                    'models': ['random_forest', 'gradient_boosting', 'neural_network'],
                    'voting': 'soft'
                },
                'severity_predictor': {
                    'type': 'regression',
                    'model': 'gradient_boosting',
                    'features': 50
                },
                'anomaly_detector': {
                    'type': 'isolation_forest',
                    'contamination': 0.1
                },
                'clustering': {
                    'algorithm': 'dbscan',
                    'min_samples': 3,
                    'eps': 0.5
                }
            },
            'analysis': {
                'deep_learning': True,
                'nlp_analysis': True,
                'graph_analysis': True,
                'time_series': True,
                'ensemble_methods': True
            },
            'performance': {
                'max_workers': 8,
                'batch_size': 32,
                'memory_limit': '4GB',
                'gpu_acceleration': False
            },
            'reporting': {
                'interactive_plots': True,
                'executive_summary': True,
                'technical_details': True,
                'remediation_guide': True
            }
        }
        
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = yaml.safe_load(f)
                # Deep merge configurations
                self.deep_merge_config(default_config, user_config)
            except Exception as e:
                self.logger.error(f"Error loading config: {e}")
        
        return default_config
    
    def deep_merge_config(self, base: dict, override: dict) -> dict:
        """Deep merge configuration dictionaries"""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self.deep_merge_config(base[key], value)
            else:
                base[key] = value
        return base
    
    def setup_logging(self):
        """Setup advanced logging with multiple handlers"""
        log_dir = os.path.join(self.output_dir, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        # Create formatters
        detailed_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
        )
        simple_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # File handlers
        main_handler = logging.FileHandler(os.path.join(log_dir, 'ai_analyzer.log'))
        main_handler.setFormatter(detailed_formatter)
        main_handler.setLevel(logging.DEBUG)
        
        error_handler = logging.FileHandler(os.path.join(log_dir, 'errors.log'))
        error_handler.setFormatter(detailed_formatter)
        error_handler.setLevel(logging.ERROR)
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(simple_formatter)
        console_handler.setLevel(logging.INFO)
        
        # Setup logger
        self.logger = logging.getLogger('AdvancedAIAnalyzer')
        self.logger.setLevel(logging.DEBUG)
        self.logger.addHandler(main_handler)
        self.logger.addHandler(error_handler)
        self.logger.addHandler(console_handler)
    
    def initialize_ai_models(self):
        """Initialize advanced AI models"""
        self.logger.info("Initializing advanced AI models...")
        
        # Vulnerability Classification Models
        self.models['vulnerability_classifier'] = {
            'random_forest': RandomForestClassifier(
                n_estimators=200,
                max_depth=20,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42,
                n_jobs=-1
            ),
            'gradient_boosting': GradientBoostingClassifier(
                n_estimators=200,
                learning_rate=0.1,
                max_depth=10,
                random_state=42
            ),
            'svm': SVC(
                kernel='rbf',
                probability=True,
                random_state=42
            ),
            'neural_network': MLPClassifier(
                hidden_layer_sizes=(100, 50, 25),
                activation='relu',
                solver='adam',
                alpha=0.001,
                learning_rate='adaptive',
                max_iter=1000,
                random_state=42
            )
        }
        
        # Severity Prediction Models
        self.models['severity_predictor'] = {
            'gradient_boosting': GradientBoostingClassifier(
                n_estimators=150,
                learning_rate=0.1,
                max_depth=8,
                random_state=42
            ),
            'neural_network': MLPRegressor(
                hidden_layer_sizes=(64, 32),
                activation='relu',
                solver='adam',
                alpha=0.001,
                learning_rate='adaptive',
                max_iter=1000,
                random_state=42
            )
        }
        
        # Anomaly Detection Models
        self.models['anomaly_detector'] = {
            'isolation_forest': IsolationForest(
                contamination=0.1,
                random_state=42,
                n_jobs=-1
            ),
            'one_class_svm': OneClassSVM(
                kernel='rbf',
                gamma='scale',
                nu=0.1
            )
        }
        
        # Clustering Models
        self.models['clustering'] = {
            'kmeans': KMeans(n_clusters=5, random_state=42),
            'dbscan': DBSCAN(eps=0.5, min_samples=3),
            'agglomerative': AgglomerativeClustering(n_clusters=5)
        }
        
        # Deep Learning Models (if available)
        if TF_AVAILABLE:
            self.models['deep_learning'] = {
                'vulnerability_lstm': self.build_lstm_model(),
                'severity_cnn': self.build_cnn_model(),
                'attention_transformer': self.build_transformer_model()
            }
        
        # NLP Models (if available)
        if NLP_AVAILABLE:
            self.models['nlp'] = {
                'vulnerability_classifier': pipeline(
                    "text-classification",
                    model="joeddav/distilbert-base-uncased-go-emotions-student"
                ),
                'sentiment_analyzer': pipeline("sentiment-analysis"),
                'ner_extractor': pipeline("ner")
            }
        
        # Vectorizers
        self.vectorizers = {
            'tfidf': TfidfVectorizer(
                max_features=5000,
                stop_words='english',
                ngram_range=(1, 3),
                min_df=2,
                max_df=0.95
            ),
            'count': CountVectorizer(
                max_features=3000,
                stop_words='english',
                ngram_range=(1, 2)
            )
        }
        
        # Scalers
        self.scalers = {
            'standard': StandardScaler(),
            'robust': RobustScaler()
        }
        
        self.logger.info("AI models initialized successfully")
    
    def build_lstm_model(self) -> tf.keras.Model:
        """Build LSTM model for vulnerability analysis"""
        model = Sequential([
            Embedding(input_dim=10000, output_dim=128, input_length=100),
            LSTM(128, return_sequences=True, dropout=0.2),
            LSTM(64, dropout=0.2),
            Dense(64, activation='relu'),
            Dropout(0.3),
            Dense(32, activation='relu'),
            Dense(5, activation='softmax')  # 5 vulnerability types
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def build_cnn_model(self) -> tf.keras.Model:
        """Build CNN model for severity prediction"""
        model = Sequential([
            Conv1D(128, 3, activation='relu', input_shape=(100, 1)),
            Conv1D(64, 3, activation='relu'),
            Dropout(0.3),
            Conv1D(32, 3, activation='relu'),
            Dropout(0.3),
            Dense(64, activation='relu'),
            Dense(1, activation='linear')  # Regression output
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    def build_transformer_model(self) -> tf.keras.Model:
        """Build transformer model for advanced analysis"""
        # Simplified transformer architecture
        inputs = Input(shape=(100,))
        embedding = Embedding(input_dim=10000, output_dim=128)(inputs)
        
        # Multi-head attention (simplified)
        attention = Dense(128, activation='relu')(embedding)
        attention = Dense(64, activation='relu')(attention)
        
        # Feed forward
        ff = Dense(128, activation='relu')(attention)
        ff = Dense(64, activation='relu')(ff)
        
        # Output
        outputs = Dense(5, activation='softmax')(ff)
        
        model = Model(inputs=inputs, outputs=outputs)
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def load_target_data(self):
        """Load and process all available target data"""
        self.logger.info("Loading target data...")
        
        data_sources = {
            'subdomains': self.load_file('all-subdomains.txt'),
            'alive_subdomains': self.load_file('alive-subdomains.txt'),
            'urls': self.load_file('all-urls.txt'),
            'technology': self.load_technology_data(),
            'ports': self.load_port_data(),
            'vulnerabilities': self.load_vulnerability_data(),
            'content': self.load_content_data(),
            'js_files': self.load_file('js-files.txt'),
            'parameters': self.load_file('parameters-urls.txt')
        }
        
        for name, data in data_sources.items():
            if data:
                self.target_data[name] = data
                self.logger.info(f"Loaded {len(data)} entries from {name}")
        
        # Create comprehensive dataset
        self.create_comprehensive_dataset()
    
    def create_comprehensive_dataset(self):
        """Create comprehensive dataset for AI analysis"""
        self.logger.info("Creating comprehensive dataset...")
        
        # Combine all data sources
        self.dataset = []
        
        # Process subdomains
        for subdomain in self.target_data.get('alive_subdomains', []):
            entry = {
                'type': 'subdomain',
                'url': subdomain,
                'domain': self.extract_domain(subdomain),
                'technologies': self.target_data.get('technology', {}).get(subdomain, []),
                'ports': self.target_data.get('ports', {}).get(subdomain, []),
                'vulnerabilities': self.target_data.get('vulnerabilities', {}).get(subdomain, []),
                'content': self.target_data.get('content', {}).get(subdomain, {}),
                'features': self.extract_features(subdomain)
            }
            self.dataset.append(entry)
        
        # Process URLs
        for url in self.target_data.get('urls', []):
            entry = {
                'type': 'url',
                'url': url,
                'domain': self.extract_domain(url),
                'features': self.extract_features(url),
                'parameters': self.extract_parameters(url)
            }
            self.dataset.append(entry)
        
        self.logger.info(f"Created dataset with {len(self.dataset)} entries")
    
    def extract_features(self, target: str) -> Dict[str, Any]:
        """Extract comprehensive features from target"""
        features = {}
        
        # URL-based features
        parsed = urlparse(target)
        features['url_length'] = len(target)
        features['path_length'] = len(parsed.path)
        features['query_length'] = len(parsed.query)
        features['fragment_length'] = len(parsed.fragment)
        features['path_depth'] = parsed.path.count('/')
        features['has_query'] = bool(parsed.query)
        features['has_fragment'] = bool(parsed.fragment)
        features['is_https'] = parsed.scheme == 'https'
        features['port'] = parsed.port or (443 if parsed.scheme == 'https' else 80)
        
        # Domain features
        domain = parsed.netloc.split(':')[0]
        features['domain_length'] = len(domain)
        features['subdomain_count'] = domain.count('.')
        features['has_numbers'] = bool(re.search(r'\d', domain))
        features['has_hyphens'] = '-' in domain
        
        # Path features
        features['has_admin'] = 'admin' in parsed.path.lower()
        features['has_api'] = 'api' in parsed.path.lower()
        features['has_login'] = 'login' in parsed.path.lower()
        features['has_upload'] = 'upload' in parsed.path.lower()
        features['has_download'] = 'download' in parsed.path.lower()
        
        return features
    
    def extract_parameters(self, url: str) -> List[str]:
        """Extract parameters from URL"""
        parsed = urlparse(url)
        if parsed.query:
            return [param.split('=')[0] for param in parsed.query.split('&')]
        return []
    
    def analyze_vulnerabilities(self):
        """Perform advanced vulnerability analysis"""
        self.logger.info("Starting advanced vulnerability analysis...")
        
        # Multi-threaded analysis
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.config['performance']['max_workers']) as executor:
            futures = [
                executor.submit(self.analyze_vulnerability_patterns),
                executor.submit(self.analyze_technology_vulnerabilities),
                executor.submit(self.analyze_parameter_vulnerabilities),
                executor.submit(self.analyze_content_vulnerabilities),
                executor.submit(self.analyze_network_vulnerabilities)
            ]
            
            for future in concurrent.futures.as_completed(futures):
                try:
                    result = future.result()
                    self.analysis_results.update(result)
                except Exception as e:
                    self.logger.error(f"Analysis task failed: {e}")
        
        # AI-powered correlation analysis
        self.correlate_findings()
        
        # Generate insights
        self.generate_insights()
    
    def analyze_vulnerability_patterns(self) -> Dict[str, Any]:
        """Analyze vulnerability patterns using AI"""
        self.logger.info("Analyzing vulnerability patterns...")
        
        findings = []
        
        # Load vulnerability data
        vuln_data = self.target_data.get('vulnerabilities', {})
        
        for target, vulnerabilities in vuln_data.items():
            for vuln in vulnerabilities:
                # Extract features
                features = self.extract_vulnerability_features(vuln)
                
                # Predict vulnerability type using AI
                vuln_type = self.predict_vulnerability_type(features)
                
                # Predict severity
                severity = self.predict_severity(features)
                
                # Detect anomalies
                is_anomaly = self.detect_anomaly(features)
                
                finding = {
                    'target': target,
                    'type': vuln_type,
                    'severity': severity,
                    'confidence': self.calculate_confidence(features),
                    'is_anomaly': is_anomaly,
                    'features': features,
                    'raw_data': vuln
                }
                findings.append(finding)
        
        return {'vulnerability_patterns': findings}
    
    def extract_vulnerability_features(self, vuln: Dict[str, Any]) -> List[float]:
        """Extract features from vulnerability data"""
        features = []
        
        # Text-based features
        description = vuln.get('description', '')
        features.append(len(description))
        features.append(len(description.split()))
        features.append(description.count('.'))
        features.append(description.count('http'))
        
        # Severity features
        severity_map = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1, 'info': 0}
        features.append(severity_map.get(vuln.get('severity', 'info'), 0))
        
        # Type features
        type_map = {
            'sql_injection': 0, 'xss': 1, 'lfi': 2, 'rce': 3, 
            'idor': 4, 'ssrf': 5, 'xxe': 6, 'csrf': 7, 'unknown': 8
        }
        features.append(type_map.get(vuln.get('type', 'unknown'), 8))
        
        # Confidence features
        features.append(vuln.get('confidence', 0.5))
        
        return features
    
    def predict_vulnerability_type(self, features: List[float]) -> str:
        """Predict vulnerability type using AI models"""
        if not self.models['vulnerability_classifier']:
            return 'unknown'
        
        # Use ensemble prediction
        predictions = []
        for model_name, model in self.models['vulnerability_classifier'].items():
            try:
                if hasattr(model, 'predict'):
                    pred = model.predict([features])[0]
                    predictions.append(pred)
            except:
                continue
        
        if predictions:
            # Majority voting
            type_map = {0: 'sql_injection', 1: 'xss', 2: 'lfi', 3: 'rce', 4: 'idor'}
            return type_map.get(max(set(predictions), key=predictions.count), 'unknown')
        
        return 'unknown'
    
    def predict_severity(self, features: List[float]) -> str:
        """Predict vulnerability severity using AI"""
        if not self.models['severity_predictor']:
            return 'medium'
        
        try:
            model = self.models['severity_predictor']['gradient_boosting']
            if hasattr(model, 'predict'):
                pred = model.predict([features])[0]
                severity_map = {0: 'info', 1: 'low', 2: 'medium', 3: 'high', 4: 'critical'}
                return severity_map.get(int(pred), 'medium')
        except:
            pass
        
        return 'medium'
    
    def detect_anomaly(self, features: List[float]) -> bool:
        """Detect anomalies using AI models"""
        if not self.models['anomaly_detector']:
            return False
        
        try:
            model = self.models['anomaly_detector']['isolation_forest']
            if hasattr(model, 'predict'):
                pred = model.predict([features])[0]
                return pred == -1  # -1 indicates anomaly
        except:
            pass
        
        return False
    
    def calculate_confidence(self, features: List[float]) -> float:
        """Calculate confidence score for prediction"""
        # Simple confidence calculation based on feature quality
        confidence = 0.5
        
        # Adjust based on feature completeness
        if len(features) > 5:
            confidence += 0.2
        
        # Adjust based on feature values
        if any(f > 0 for f in features):
            confidence += 0.2
        
        return min(1.0, confidence)
    
    def correlate_findings(self):
        """Correlate findings using graph analysis"""
        self.logger.info("Correlating findings...")
        
        # Create correlation graph
        G = nx.Graph()
        
        # Add nodes for each finding
        for finding in self.analysis_results.get('vulnerability_patterns', []):
            G.add_node(finding['target'], **finding)
        
        # Add edges based on correlations
        for i, finding1 in enumerate(self.analysis_results.get('vulnerability_patterns', [])):
            for j, finding2 in enumerate(self.analysis_results.get('vulnerability_patterns', [])):
                if i != j:
                    correlation = self.calculate_correlation(finding1, finding2)
                    if correlation > 0.7:
                        G.add_edge(finding1['target'], finding2['target'], weight=correlation)
        
        # Analyze graph structure
        self.analysis_results['correlation_analysis'] = {
            'graph': G,
            'clusters': list(nx.connected_components(G)),
            'centrality': nx.degree_centrality(G),
            'betweenness': nx.betweenness_centrality(G)
        }
    
    def calculate_correlation(self, finding1: Dict, finding2: Dict) -> float:
        """Calculate correlation between two findings"""
        correlation = 0.0
        
        # Type correlation
        if finding1['type'] == finding2['type']:
            correlation += 0.3
        
        # Severity correlation
        if finding1['severity'] == finding2['severity']:
            correlation += 0.2
        
        # Domain correlation
        domain1 = self.extract_domain(finding1['target'])
        domain2 = self.extract_domain(finding2['target'])
        if domain1 == domain2:
            correlation += 0.4
        
        # Feature correlation
        features1 = finding1.get('features', [])
        features2 = finding2.get('features', [])
        if len(features1) == len(features2):
            feature_corr = np.corrcoef(features1, features2)[0, 1]
            if not np.isnan(feature_corr):
                correlation += feature_corr * 0.1
        
        return min(1.0, correlation)
    
    def generate_insights(self):
        """Generate AI-powered insights"""
        self.logger.info("Generating AI insights...")
        
        insights = {
            'summary': self.generate_summary(),
            'trends': self.analyze_trends(),
            'recommendations': self.generate_recommendations(),
            'risk_assessment': self.assess_risk(),
            'visualizations': self.generate_visualizations()
        }
        
        self.analysis_results['insights'] = insights
    
    def generate_summary(self) -> Dict[str, Any]:
        """Generate executive summary"""
        findings = self.analysis_results.get('vulnerability_patterns', [])
        
        summary = {
            'total_findings': len(findings),
            'critical_findings': len([f for f in findings if f['severity'] == 'critical']),
            'high_findings': len([f for f in findings if f['severity'] == 'high']),
            'medium_findings': len([f for f in findings if f['severity'] == 'medium']),
            'low_findings': len([f for f in findings if f['severity'] == 'low']),
            'anomalies': len([f for f in findings if f.get('is_anomaly', False)]),
            'top_vulnerability_types': self.get_top_vulnerability_types(findings),
            'most_affected_targets': self.get_most_affected_targets(findings)
        }
        
        return summary
    
    def get_top_vulnerability_types(self, findings: List[Dict]) -> List[Tuple[str, int]]:
        """Get top vulnerability types"""
        type_counts = Counter([f['type'] for f in findings])
        return type_counts.most_common(5)
    
    def get_most_affected_targets(self, findings: List[Dict]) -> List[Tuple[str, int]]:
        """Get most affected targets"""
        target_counts = Counter([f['target'] for f in findings])
        return target_counts.most_common(5)
    
    def analyze_trends(self) -> Dict[str, Any]:
        """Analyze trends in findings"""
        findings = self.analysis_results.get('vulnerability_patterns', [])
        
        trends = {
            'severity_distribution': self.calculate_severity_distribution(findings),
            'type_distribution': self.calculate_type_distribution(findings),
            'target_distribution': self.calculate_target_distribution(findings),
            'confidence_distribution': self.calculate_confidence_distribution(findings)
        }
        
        return trends
    
    def calculate_severity_distribution(self, findings: List[Dict]) -> Dict[str, int]:
        """Calculate severity distribution"""
        severity_counts = Counter([f['severity'] for f in findings])
        return dict(severity_counts)
    
    def calculate_type_distribution(self, findings: List[Dict]) -> Dict[str, int]:
        """Calculate type distribution"""
        type_counts = Counter([f['type'] for f in findings])
        return dict(type_counts)
    
    def calculate_target_distribution(self, findings: List[Dict]) -> Dict[str, int]:
        """Calculate target distribution"""
        target_counts = Counter([f['target'] for f in findings])
        return dict(target_counts)
    
    def calculate_confidence_distribution(self, findings: List[Dict]) -> Dict[str, int]:
        """Calculate confidence distribution"""
        confidence_ranges = {'high': 0, 'medium': 0, 'low': 0}
        
        for finding in findings:
            confidence = finding.get('confidence', 0.5)
            if confidence >= 0.8:
                confidence_ranges['high'] += 1
            elif confidence >= 0.5:
                confidence_ranges['medium'] += 1
            else:
                confidence_ranges['low'] += 1
        
        return confidence_ranges
    
    def generate_recommendations(self) -> List[str]:
        """Generate AI-powered recommendations"""
        recommendations = []
        
        findings = self.analysis_results.get('vulnerability_patterns', [])
        
        # Critical findings recommendations
        critical_count = len([f for f in findings if f['severity'] == 'critical'])
        if critical_count > 0:
            recommendations.append(f"Immediately address {critical_count} critical vulnerabilities")
        
        # Type-specific recommendations
        type_counts = Counter([f['type'] for f in findings])
        for vuln_type, count in type_counts.most_common(3):
            if vuln_type == 'sql_injection':
                recommendations.append("Implement parameterized queries and input validation")
            elif vuln_type == 'xss':
                recommendations.append("Implement output encoding and Content Security Policy")
            elif vuln_type == 'lfi':
                recommendations.append("Implement proper file access controls and path validation")
        
        # Anomaly recommendations
        anomaly_count = len([f for f in findings if f.get('is_anomaly', False)])
        if anomaly_count > 0:
            recommendations.append(f"Investigate {anomaly_count} anomalous findings for potential new attack vectors")
        
        return recommendations
    
    def assess_risk(self) -> Dict[str, Any]:
        """Assess overall risk"""
        findings = self.analysis_results.get('vulnerability_patterns', [])
        
        # Calculate risk score
        risk_score = 0
        for finding in findings:
            severity_weights = {'critical': 10, 'high': 7, 'medium': 4, 'low': 2, 'info': 1}
            risk_score += severity_weights.get(finding['severity'], 1)
        
        # Normalize risk score
        max_possible_score = len(findings) * 10
        normalized_risk = risk_score / max_possible_score if max_possible_score > 0 else 0
        
        # Determine risk level
        if normalized_risk >= 0.8:
            risk_level = 'critical'
        elif normalized_risk >= 0.6:
            risk_level = 'high'
        elif normalized_risk >= 0.4:
            risk_level = 'medium'
        elif normalized_risk >= 0.2:
            risk_level = 'low'
        else:
            risk_level = 'minimal'
        
        return {
            'risk_score': normalized_risk,
            'risk_level': risk_level,
            'total_risk': risk_score,
            'max_possible_risk': max_possible_score
        }
    
    def generate_visualizations(self) -> Dict[str, Any]:
        """Generate advanced visualizations"""
        self.logger.info("Generating visualizations...")
        
        viz_dir = os.path.join(self.output_dir, 'visualizations')
        os.makedirs(viz_dir, exist_ok=True)
        
        findings = self.analysis_results.get('vulnerability_patterns', [])
        
        visualizations = {}
        
        # Severity distribution pie chart
        severity_counts = self.calculate_severity_distribution(findings)
        if severity_counts:
            fig = px.pie(
                values=list(severity_counts.values()),
                names=list(severity_counts.keys()),
                title="Vulnerability Severity Distribution"
            )
            fig.write_html(os.path.join(viz_dir, 'severity_distribution.html'))
            visualizations['severity_distribution'] = 'severity_distribution.html'
        
        # Type distribution bar chart
        type_counts = self.calculate_type_distribution(findings)
        if type_counts:
            fig = px.bar(
                x=list(type_counts.keys()),
                y=list(type_counts.values()),
                title="Vulnerability Type Distribution"
            )
            fig.write_html(os.path.join(viz_dir, 'type_distribution.html'))
            visualizations['type_distribution'] = 'type_distribution.html'
        
        # Target distribution
        target_counts = self.calculate_target_distribution(findings)
        if target_counts:
            fig = px.bar(
                x=list(target_counts.keys()),
                y=list(target_counts.values()),
                title="Vulnerabilities by Target"
            )
            fig.write_html(os.path.join(viz_dir, 'target_distribution.html'))
            visualizations['target_distribution'] = 'target_distribution.html'
        
        return visualizations
    
    def save_results(self):
        """Save analysis results"""
        self.logger.info("Saving analysis results...")
        
        # Save JSON results
        results_file = os.path.join(self.output_dir, 'ai_analysis_results.json')
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(self.analysis_results, f, indent=2, ensure_ascii=False, default=str)
        
        # Save human-readable report
        report_file = os.path.join(self.output_dir, 'ai_analysis_report.md')
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(self.generate_markdown_report())
        
        self.logger.info(f"Results saved to {results_file} and {report_file}")
    
    def generate_markdown_report(self) -> str:
        """Generate markdown report"""
        lines = [
            "# AI-Powered Vulnerability Analysis Report",
            "",
            f"Generated: {datetime.now().isoformat()}",
            f"Analyzer: Advanced AI Vulnerability Analyzer v2.0",
            "",
            "## Executive Summary",
            ""
        ]
        
        # Add summary
        summary = self.analysis_results.get('insights', {}).get('summary', {})
        lines.extend([
            f"- **Total Findings**: {summary.get('total_findings', 0)}",
            f"- **Critical**: {summary.get('critical_findings', 0)}",
            f"- **High**: {summary.get('high_findings', 0)}",
            f"- **Medium**: {summary.get('medium_findings', 0)}",
            f"- **Low**: {summary.get('low_findings', 0)}",
            f"- **Anomalies**: {summary.get('anomalies', 0)}",
            ""
        ])
        
        # Add risk assessment
        risk = self.analysis_results.get('insights', {}).get('risk_assessment', {})
        lines.extend([
            "## Risk Assessment",
            "",
            f"- **Risk Level**: {risk.get('risk_level', 'unknown').upper()}",
            f"- **Risk Score**: {risk.get('risk_score', 0):.2f}",
            ""
        ])
        
        # Add recommendations
        recommendations = self.analysis_results.get('insights', {}).get('recommendations', [])
        if recommendations:
            lines.extend([
                "## Recommendations",
                ""
            ])
            for i, rec in enumerate(recommendations, 1):
                lines.append(f"{i}. {rec}")
            lines.append("")
        
        # Add detailed findings
        findings = self.analysis_results.get('vulnerability_patterns', [])
        if findings:
            lines.extend([
                "## Detailed Findings",
                ""
            ])
            
            for i, finding in enumerate(findings, 1):
                lines.extend([
                    f"### Finding {i}: {finding['type'].replace('_', ' ').title()}",
                    "",
                    f"- **Target**: {finding['target']}",
                    f"- **Severity**: {finding['severity'].upper()}",
                    f"- **Confidence**: {finding.get('confidence', 0):.2f}",
                    f"- **Anomaly**: {'Yes' if finding.get('is_anomaly', False) else 'No'}",
                    ""
                ])
        
        return "\n".join(lines)
    
    def run(self):
        """Main execution method"""
        try:
            self.logger.info("Starting advanced AI vulnerability analysis...")
            
            # Load data
            self.load_target_data()
            
            if not self.dataset:
                self.logger.error("No data available for analysis")
                return
            
            # Perform analysis
            self.analyze_vulnerabilities()
            
            # Save results
            self.save_results()
            
            self.logger.info("AI vulnerability analysis completed successfully")
            
        except Exception as e:
            self.logger.error(f"Error in analysis: {e}")
            raise

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Advanced AI-Powered Vulnerability Analyzer')
    parser.add_argument('workdir', help='Working directory with scan results')
    parser.add_argument('output_dir', help='Output directory for results')
    parser.add_argument('--config', '-c', help='Configuration file (YAML format)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    
    args = parser.parse_args()
    
    # Set logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Run analysis
    analyzer = AdvancedAIVulnerabilityAnalyzer(args.workdir, args.output_dir, args.config)
    analyzer.run()

if __name__ == "__main__":
    main()

