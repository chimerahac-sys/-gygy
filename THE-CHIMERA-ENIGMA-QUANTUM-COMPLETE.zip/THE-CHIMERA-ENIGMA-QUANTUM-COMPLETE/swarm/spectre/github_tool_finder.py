import os
import sys
import json
import requests
import argparse

def search_github(query: str, api_key: str) -> None:
    """Search GitHub for repositories."""
    headers = {
        'Accept': 'application/vnd.github.v3+json',
    }
    if api_key:
        headers['Authorization'] = f'token {api_key}'

    url = f'https://api.github.com/search/repositories?q={query}'
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        results = response.json()
        for item in results.get('items', []):
            print(f"Name: {item['name']}")
            print(f"Description: {item['description']}")
            print(f"URL: {item['html_url']}")
            print("-" * 50)
    else:
        print(f"Error: {response.status_code} - {response.text}")

def main():
    parser = argparse.ArgumentParser(description='GitHub Tool Finder')
    parser.add_argument('query', help='Search query for GitHub repositories')
    parser.add_argument('--api-key', help='GitHub API key')
    args = parser.parse_args()

    search_github(args.query, args.api_key)

if __name__ == '__main__':
    main()
