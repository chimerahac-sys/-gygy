#!/usr/bin/env python3
# =============================================================================
#     👻 SPECTRE AGENT v5.2 - SUPER INTELLIGENT HACKER ENTITY 👻
# =============================================================================
#  World-Changing Hacking Toolkit with Quantum Supremacy + Neural Warfare
#  SUPER INTELLIGENT HACKER ENTITY - Autonomous Hacking Operations
#  Features: AI Thinking, Browser Automation, Terminal Automation, Linux Tools Integration
# =============================================================================

from core.base_agent import BaseAgent
from core.cognitive_bus import CognitiveBus
import asyncio
import os

class SpectreAgent(BaseAgent):
    """The reconnaissance agent. Finds assets and posts them to the bus."""

    def __init__(self, target, workspace_dir, bus: CognitiveBus):
        super().__init__(target, workspace_dir)
        self.bus = bus

    async def run(self):
        self.log_info(f"Spectre mission: Asset discovery starting.")
        
        toolmaster = self.bus.get('agent_toolmaster') # Agents are posted with agent_ prefix
        if not toolmaster:
            self.log_error("Toolmaster not found on the bus. Cannot execute recon tools.")
            return

        # Use Toolmaster to run subfinder
        self.log_info(f"Executing subfinder for {self.target}")
        subfinder_command = f"subfinder -d {self.target} -o {self.output_dir}/subdomains.txt -silent"
        result = await toolmaster.execute(subfinder_command, "Subdomain enumeration with subfinder.")

        if result and result.get("exit_code") == 0:
            self.log_success("Subfinder execution complete.")
            subdomains = []
            try:
                with open(f"{self.output_dir}/subdomains.txt", 'r') as f:
                    subdomains = [line.strip() for line in f if line.strip()]
            except FileNotFoundError:
                self.log_error("Subfinder output file not found.")
            
            if subdomains:
                self.log_info(f"Found {len(subdomains)} subdomains. Posting to Cognitive Bus.")
                self.bus.post('subdomains', subdomains)
        else:
            self.log_error("Subfinder execution failed.")

        self.log_success("Spectre mission complete.")
            
            if subdomains:
                self.log_info(f"Found {len(subdomains)} subdomains. Posting to Cognitive Bus.")
                self.bus.post('subdomains', subdomains)
        else:
            self.log_error("Subfinder execution failed.")

        self.log_success("Spectre mission complete.")

            
            if subdomains:
                self.log_info(f"Found {len(subdomains)} subdomains. Posting to Cognitive Bus.")
                self.bus.post('subdomains', subdomains)
        else:
            self.log_error("Subfinder execution failed.")

        self.log_success("Spectre mission complete.")

            
            if subdomains:
                self.log_info(f"Found {len(subdomains)} subdomains. Posting to Cognitive Bus.")
                self.bus.post('subdomains', subdomains)
        else:
            self.log_error("Subfinder execution failed.")

        self.log_success("Spectre mission complete.")

