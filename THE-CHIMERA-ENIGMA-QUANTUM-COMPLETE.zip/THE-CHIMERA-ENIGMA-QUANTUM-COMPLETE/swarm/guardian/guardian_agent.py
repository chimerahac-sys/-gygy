#!/usr/bin/env python3
# =============================================================================
#     🛡️ GUARDIAN AGENT v5.2 - SUPER INTELLIGENT HACKER ENTITY 🛡️
# =============================================================================
#  World-Changing Hacking Toolkit with Quantum Supremacy + Neural Warfare
#  SUPER INTELLIGENT HACKER ENTITY - Autonomous Hacking Operations
#  Features: AI Thinking, Browser Automation, Terminal Automation, Linux Tools Integration
# =============================================================================

from core.base_agent import BaseAgent
from core.cognitive_bus import CognitiveBus
from default_api import write_file
import os
import traceback

try:
    import google.generativeai as genai
except ImportError:
    pass # Orchestrator handles this

class GuardianAgent(BaseAgent):
    """A meta-agent that monitors other agents and attempts to fix them if they fail."""

    def __init__(self, target, workspace_dir, bus: CognitiveBus):
        super().__init__(target, workspace_dir)
        self.bus = bus
        self.model = None
        self.setup_gemini()

    def setup_gemini(self):
        # This agent NEEDS Gemini to function.
        api_key = os.getenv("GEMINI_API_KEY")
        if api_key:
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel('gemini-pro')
            self.log_success("Guardian's Healing Core (Gemini) is online.")
        else:
            self.log_warning("Guardian cannot function without a Gemini API Key.")

    async def heal(self, failed_agent_name: str, exception: Exception) -> bool:
        """Attempts to heal a failed agent by rewriting its code."""
        if not self.model:
            self.log_error("Healing is not possible. Gemini Core is offline.")
            return False

        self.log_warning(f"Guardian intervening! Agent '{failed_agent_name}' has failed.")
        self.log_info(f"Analyzing error: {exception}")

        # 1. Read the failed agent's source code
        agent_file_path = self.root_dir / 'swarm' / failed_agent_name / f"{failed_agent_name}_agent.py"
        if not agent_file_path.exists():
             # Fallback for inconsistent naming
            agent_file_path = self.root_dir / 'swarm' / failed_agent_name
            py_files = list(agent_file_path.glob('*.py'))
            if not py_files or py_files[0].name.startswith('__'):
                 self.log_error(f"Could not find source code for agent '{failed_agent_name}'. Cannot heal.")
                 return False
            agent_file_path = py_files[0]

        try:
            with open(agent_file_path, 'r') as f:
                source_code = f.read()
        except Exception as e:
            self.log_error(f"Could not read source code for agent '{failed_agent_name}': {e}")
            return False

        # 2. Construct the healing prompt
        error_traceback = traceback.format_exc()
        prompt = f"""
        You are the Guardian of the Chimera Swarm, a master AI programmer specializing in self-correction.
        The agent '{failed_agent_name}' has failed during its mission.

        ERROR TRACEBACK:
        ---
        {error_traceback}
        ---

        AGENT'S SOURCE CODE:
        ---
        {source_code}
        ---

        Your task is to analyze the error and the code, and provide a corrected version of the Python code for the ENTIRE file.
        Your goal is to fix the bug so the agent can run successfully. Your corrected code should be robust and production-quality.
        Do NOT just comment out the failing code. Find the root cause and fix it.
        
        Respond with ONLY the complete, corrected, and fully functional Python code for the file. Do not include any other text, explanations, or markdown formatting.
        """

        # 3. Ask Gemini to heal the code
        self.log_info("Consulting Healing Core to generate a fix...")
        try:
            response = await self.model.generate_content_async(prompt)
            healed_code = response.text.replace('```python', '').replace('```', '')

            # Basic validation to ensure it's not an empty response
            if len(healed_code) < 50 or "import" not in healed_code:
                raise ValueError("Healing Core provided an invalid or empty response.")

        except Exception as e:
            self.log_error(f"Healing Core failed to generate a fix: {e}")
            return False

        # 4. Apply the fix
        self.log_warning(f"Applying self-healing patch to '{failed_agent_name}'...")
        try:
            write_file(file_path=str(agent_file_path), content=healed_code)
            self.log_success(f"Agent '{failed_agent_name}' has been healed.")
            return True
        except Exception as e:
            self.log_error(f"Failed to apply healing patch: {e}")
            return False

    async def run(self):
        """Guardian agent is reactive, it does not run in sequence."""
        self.log_info("Guardian Agent is online and monitoring the Swarm.")
        pass
        except Exception as e:
            self.log_error(f"Failed to apply healing patch: {e}")
            return False

    async def run(self):
        """Guardian agent is reactive, it does not run in sequence."""
        self.log_info("Guardian Agent is online and monitoring the Swarm.")
        pass

        except Exception as e:
            self.log_error(f"Failed to apply healing patch: {e}")
            return False

    async def run(self):
        """Guardian agent is reactive, it does not run in sequence."""
        self.log_info("Guardian Agent is online and monitoring the Swarm.")
        pass

        except Exception as e:
            self.log_error(f"Failed to apply healing patch: {e}")
            return False

    async def run(self):
        """Guardian agent is reactive, it does not run in sequence."""
        self.log_info("Guardian Agent is online and monitoring the Swarm.")
        pass

