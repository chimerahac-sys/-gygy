#!/usr/bin/env python3
import os
import sys
import json
import sqlite3
import argparse
from datetime import datetime


SCHEMA = [
    "CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)",
    "CREATE TABLE IF NOT EXISTS cves (cve_id TEXT PRIMARY KEY, description TEXT, cvss REAL, published TEXT)",
    "CREATE TABLE IF NOT EXISTS kev (cve_id TEXT PRIMARY KEY, date_added TEXT)",
    "CREATE TABLE IF NOT EXISTS exploits (source TEXT, ref TEXT PRIMARY KEY, cve_id TEXT, title TEXT)"
]


def ensure_db(path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    for stmt in SCHEMA:
        cur.execute(stmt)
    conn.commit()
    return conn


def seed_mock(conn):
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    cur.execute("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", ("last_update", now))
    samples = [
        ("CVE-2024-0001", "Sample RCE vuln in component X", 9.8, "2024-01-10"),
        ("CVE-2023-40012", "Directory traversal in product Y", 7.5, "2023-10-05")
    ]
    for row in samples:
        cur.execute("INSERT OR REPLACE INTO cves(cve_id,description,cvss,published) VALUES(?,?,?,?)", row)
    kev = [("CVE-2024-0001", "2024-02-01")]
    for row in kev:
        cur.execute("INSERT OR REPLACE INTO kev(cve_id,date_added) VALUES(?,?)", row)
    exploits = [("exploitdb", "EDB-00001", "CVE-2024-0001", "RCE PoC for component X")]
    for row in exploits:
        cur.execute("INSERT OR REPLACE INTO exploits(source,ref,cve_id,title) VALUES(?,?,?,?)", row)
    conn.commit()


def main():
    ap = argparse.ArgumentParser(description="Threat intelligence feeder (local DB)")
    ap.add_argument("--db", required=True, help="SQLite DB path (e.g., knowledge_base/threat.db)")
    ap.add_argument("--mock", action="store_true", help="Seed with mock data instead of fetching")
    args = ap.parse_args()

    conn = ensure_db(args.db)
    try:
        if args.mock:
            seed_mock(conn)
        # Real fetchers could be added here (NVD, KEV, Exploit-DB APIs) with API keys
    finally:
        conn.close()
    print(f"Threat intel updated: {args.db}")


if __name__ == "__main__":
    main()


