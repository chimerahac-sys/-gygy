#!/usr/bin/env python3
# =============================================================================
#     🕸️ WEAVER AGENT v5.2 - SUPER INTELLIGENT HACKER ENTITY 🕸️
# =============================================================================
#  World-Changing Hacking Toolkit with Quantum Supremacy + Neural Warfare
#  SUPER INTELLIGENT HACKER ENTITY - Autonomous Hacking Operations
#  Features: AI Thinking, Browser Automation, Terminal Automation, Linux Tools Integration
# =============================================================================

from core.base_agent import BaseAgent
from core.cognitive_bus import CognitiveBus
from default_api import write_file
import os

try:
    import google.generativeai as genai
except ImportError:
    pass

class WeaverAgent(BaseAgent):
    """An agent that can write new agents based on a goal."""

    def __init__(self, target, workspace_dir, bus: CognitiveBus):
        super().__init__(target, workspace_dir)
        self.bus = bus
        self.model = None
        self.setup_gemini()

    def setup_gemini(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if api_key:
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel('gemini-pro')
            self.log_success("Weaver's Creation Core (Gemini) is online.")
        else:
            self.log_warning("Weaver cannot function without a Gemini API Key.")

    async def create_new_agent(self, agent_name: str, agent_goal: str) -> bool:
        if not self.model:
            self.log_error("Creation is not possible. Gemini Core is offline.")
            return False

        self.log_warning(f"Weaver has been tasked to create a new agent: '{agent_name}'")
        self.log_info(f"Goal for new agent: {agent_goal}")

        prompt = f"""
        You are the 'Weaver', a master AI that writes other AI agents for the Chimera Swarm.
        Your task is to write the complete Python code for a new agent named '{agent_name}Agent'.
        The new agent's goal is: '{agent_goal}'.
        
        The new agent MUST inherit from 'core.base_agent.BaseAgent'.
        The new agent MUST implement the `async def run(self)` method.
        The agent can access the shared 'self.bus' (CognitiveBus) to get and post data.
        The agent can use 'self.log_info()', 'self.log_success()', etc. for logging.
        If the agent needs to run external shell commands, it should get the 'toolmaster' agent from the bus and use `await toolmaster.execute(command, description)`.

        The code should be complete, robust, and ready to be executed.
        Provide ONLY the complete, new Python code for the agent file. Do not include any other text, explanations, or markdown formatting.
        """

        try:
            response = await self.model.generate_content_async(prompt)
            new_agent_code = response.text.replace('```python', '').replace('```', '')

            if len(new_agent_code) < 100 or "class" not in new_agent_code:
                raise ValueError("Weaver provided an invalid or empty response.")

            # Create the new agent's directory and file
            new_agent_dir = self.root_dir / 'swarm' / agent_name.lower()
            os.makedirs(new_agent_dir, exist_ok=True)
            new_agent_path = new_agent_dir / f"{agent_name.lower()}_agent.py"

            write_file(file_path=str(new_agent_path), content=new_agent_code)
            self.log_success(f"Successfully created new agent '{agent_name}' at {new_agent_path}")
            self.bus.post('new_agent_created', agent_name.lower())
            return True

        except Exception as e:
            self.log_error(f"Weaver failed to create new agent: {e}")
            return False

    async def run(self):
        self.log_info("Weaver Agent is online and awaiting creation tasks from the Orchestrator.")
        pass
        except Exception as e:
            self.log_error(f"Weaver failed to create new agent: {e}")
            return False

    async def run(self):
        self.log_info("Weaver Agent is online and awaiting creation tasks from the Orchestrator.")
        pass


        except Exception as e:
            self.log_error(f"Weaver failed to create new agent: {e}")
            return False

    async def run(self):
        self.log_info("Weaver Agent is online and awaiting creation tasks from the Orchestrator.")
        pass


        except Exception as e:
            self.log_error(f"Weaver failed to create new agent: {e}")
            return False

    async def run(self):
        self.log_info("Weaver Agent is online and awaiting creation tasks from the Orchestrator.")
        pass



