#!/usr/bin/env python3
# =============================================================================
#     🎓 LEARNING CORE v5.2 - SUPER INTELLIGENT HACKER ENTITY 🎓
# =============================================================================
#  World-Changing Hacking Toolkit with Quantum Supremacy + Neural Warfare
#  SUPER INTELLIGENT HACKER ENTITY - Autonomous Hacking Operations
#  Features: AI Thinking, Browser Automation, Terminal Automation, Linux Tools Integration
# =============================================================================

import json
import os
import sqlite3
from datetime import datetime

class LearningCore:
    """Records mission outcomes to enable learning from success and failure."""
    def __init__(self, workspace_dir):
        db_path = os.path.join(workspace_dir, "learning_core.db")
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.setup_database()

    def setup_database(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS missions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mission_id TEXT NOT NULL UNIQUE,
                timestamp TEXT NOT NULL,
                target TEXT NOT NULL,
                profile TEXT NOT NULL,
                success BOOLEAN NOT NULL,
                findings TEXT,
                errors TEXT
            )
        ''')
        self.conn.commit()

    def save_outcome(self, mission_id, target, profile, success, findings, errors):
        """Saves the outcome of a completed mission."""
        timestamp = datetime.now().isoformat()
        findings_json = json.dumps(findings)
        errors_json = json.dumps(errors)
        
        self.cursor.execute("""
            INSERT INTO missions (mission_id, timestamp, target, profile, success, findings, errors)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (mission_id, timestamp, target, profile, success, findings_json, errors_json))
        self.conn.commit()
        print(f"[LearningCore] Outcome for mission {mission_id} saved.")

    def get_past_failures_for_target(self, target):
        """Retrieves past failed missions for a specific target to avoid repeating mistakes."""
        self.cursor.execute("SELECT errors FROM missions WHERE target = ? AND success = 0", (target,))
        return [json.loads(row[0]) for row in self.cursor.fetchall()]

    def close(self):
        self.conn.close()
